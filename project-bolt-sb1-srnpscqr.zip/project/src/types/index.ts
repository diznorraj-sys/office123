export interface User {
  id: string;
  name: string;
  email: string;
  role: 'manager' | 'staff';
  joinDate: string;
  status: 'active' | 'inactive';
  phone?: string;
  address?: string;
  designation?: string;
  department?: string;
  profileImage?: string;
}

export interface Staff extends User {
  managerId?: string;
}

export interface Attendance {
  id: string;
  userId: string;
  date: string;
  checkIn?: string;
  checkOut?: string;
  status: 'Present' | 'Late' | 'Absent';
  workingHours?: number;
}

export interface Leave {
  id: string;
  userId: string;
  startDate: string;
  endDate: string;
  reason: string;
  status: 'Pending' | 'Approved' | 'Rejected';
  appliedDate: string;
  approvedBy?: string;
  approvedDate?: string;
}

export interface Financial {
  id: string;
  type: 'income' | 'expense';
  amount: number;
  description: string;
  date: string;
  category: string;
  recordedBy: string;
}

export interface Task {
  id: string;
  title: string;
  description: string;
  assignedTo: string;
  assignedBy: string;
  deadline: string;
  status: 'To Do' | 'In Progress' | 'Completed';
  priority: 'Low' | 'Medium' | 'High';
  createdDate: string;
}

export interface TaskActivity {
  id: string;
  taskId: string;
  userId: string;
  startTime: string;
  endTime?: string;
  duration?: number;
  isActive: boolean;
}

export interface WorkSubmission {
  id: string;
  userId: string;
  title: string;
  description: string;
  submissionDate: string;
  status: 'Submitted' | 'Reviewed' | 'In Progress';
  reviewedBy?: string;
  feedback?: string;
}

export interface Notice {
  id: string;
  title: string;
  content: string;
  publishedBy: string;
  publishedDate: string;
  priority: 'Low' | 'Medium' | 'High';
}

export interface Salary {
  id: string;
  userId: string;
  month: number;
  year: number;
  amount: number;
  bonuses?: number;
  deductions?: number;
  netAmount: number;
}

export interface Notification {
  id: string;
  userId: string;
  title: string;
  message: string;
  type: 'info' | 'success' | 'warning' | 'error';
  read: boolean;
  createdDate: string;
}

export interface DesignSubmission {
  id: string;
  userId: string;
  date: string;
  regularDesigns: number;
  completedDesigns: number;
  submittedBy: string;
  submissionTime: string;
}

export interface UserPermission {
  id: string;
  userId: string;
  canViewReports: boolean;
  canManageStaff: boolean;
  canManageFinance: boolean;
  canManageTasks: boolean;
  canViewAllAttendance: boolean;
  canApproveLeaves: boolean;
  canSendNotices: boolean;
}
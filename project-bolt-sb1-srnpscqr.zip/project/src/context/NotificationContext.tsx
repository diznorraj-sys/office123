import React, { createContext, useContext, useState, useEffect } from 'react';
import { Notification } from '../types';

interface NotificationContextType {
  notifications: Notification[];
  unreadCount: number;
  addNotification: (notification: Omit<Notification, 'id' | 'createdDate'>) => void;
  markAsRead: (notificationId: string) => void;
  markAllAsRead: () => void;
  clearNotification: (notificationId: string) => void;
}

const NotificationContext = createContext<NotificationContextType | undefined>(undefined);

export const useNotifications = () => {
  const context = useContext(NotificationContext);
  if (context === undefined) {
    throw new Error('useNotifications must be used within a NotificationProvider');
  }
  return context;
};

export const NotificationProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [notifications, setNotifications] = useState<Notification[]>([
    {
      id: '1',
      userId: '1',
      title: 'নতুন ছুটির আবেদন',
      message: 'ফাতিমা আহমেদ ছুটির জন্য আবেদন করেছে',
      type: 'info',
      read: false,
      createdDate: new Date().toISOString()
    },
    {
      id: '2',
      userId: '2',
      title: 'টাস্ক সম্পন্ন',
      message: 'আপনার "ওয়েবসাইট ডিজাইন" টাস্কটি অনুমোদিত হয়েছে',
      type: 'success',
      read: false,
      createdDate: new Date(Date.now() - 3600000).toISOString()
    },
    {
      id: '3',
      userId: '1',
      title: 'নতুন স্টাফ যোগদান',
      message: 'সারা খাতুন আজ অফিসে যোগদান করেছে',
      type: 'success',
      read: true,
      createdDate: new Date(Date.now() - 7200000).toISOString()
    }
  ]);

  const unreadCount = notifications.filter(n => !n.read).length;

  const addNotification = (notificationData: Omit<Notification, 'id' | 'createdDate'>) => {
    const newNotification: Notification = {
      ...notificationData,
      id: Date.now().toString(),
      createdDate: new Date().toISOString()
    };
    setNotifications(prev => [newNotification, ...prev]);
  };

  const markAsRead = (notificationId: string) => {
    setNotifications(prev =>
      prev.map(notification =>
        notification.id === notificationId
          ? { ...notification, read: true }
          : notification
      )
    );
  };

  const markAllAsRead = () => {
    setNotifications(prev =>
      prev.map(notification => ({ ...notification, read: true }))
    );
  };

  const clearNotification = (notificationId: string) => {
    setNotifications(prev =>
      prev.filter(notification => notification.id !== notificationId)
    );
  };

  return (
    <NotificationContext.Provider value={{
      notifications,
      unreadCount,
      addNotification,
      markAsRead,
      markAllAsRead,
      clearNotification
    }}>
      {children}
    </NotificationContext.Provider>
  );
};
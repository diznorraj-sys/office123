import React, { useState, useEffect } from 'react';
import { 
  Clock, 
  Calendar, 
  CheckCircle, 
  XCircle, 
  AlertCircle,
  PlayCircle,
  PauseCircle,
  Users
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { Attendance } from '../../types';

export const AttendanceTracker: React.FC = () => {
  const { user } = useAuth();
  const [isCheckedIn, setIsCheckedIn] = useState(false);
  const [currentTime, setCurrentTime] = useState(new Date());
  const [todayAttendance, setTodayAttendance] = useState<Attendance | null>(null);

  const [attendanceHistory, setAttendanceHistory] = useState<Attendance[]>([
    {
      id: '1',
      userId: user?.id || '2',
      date: '2025-01-28',
      checkIn: '09:15:00',
      checkOut: '18:30:00',
      status: 'Present',
      workingHours: 8.25
    },
    {
      id: '2',
      userId: user?.id || '2',
      date: '2025-01-27',
      checkIn: '09:45:00',
      checkOut: '18:15:00',
      status: 'Late',
      workingHours: 7.5
    },
    {
      id: '3',
      userId: user?.id || '2',
      date: '2025-01-26',
      checkIn: '08:55:00',
      checkOut: '17:45:00',
      status: 'Present',
      workingHours: 8.83
    }
  ]);

  // All staff attendance for managers
  const [allStaffAttendance, setAllStaffAttendance] = useState<(Attendance & { staffName: string })[]>([
    {
      id: '4',
      userId: '2',
      staffName: 'ফাতিমা আহমেদ',
      date: '2025-01-29',
      checkIn: '09:10:00',
      status: 'Present',
      workingHours: 0
    },
    {
      id: '5',
      userId: '3',
      staffName: 'রহিম উদ্দিন',
      date: '2025-01-29',
      checkIn: '09:35:00',
      status: 'Late',
      workingHours: 0
    },
    {
      id: '6',
      userId: '4',
      staffName: 'সারা খাতুন',
      date: '2025-01-29',
      checkIn: '08:50:00',
      status: 'Present',
      workingHours: 0
    }
  ]);

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(new Date());
    }, 1000);

    return () => clearInterval(timer);
  }, []);

  useEffect(() => {
    // Check if user is already checked in today
    const today = new Date().toISOString().split('T')[0];
    const todayRecord = attendanceHistory.find(
      record => record.date === today && record.userId === user?.id
    );
    
    if (todayRecord) {
      setTodayAttendance(todayRecord);
      setIsCheckedIn(!!todayRecord.checkIn && !todayRecord.checkOut);
    }
  }, [attendanceHistory, user?.id]);

  const handleCheckIn = () => {
    const now = new Date();
    const timeString = now.toTimeString().split(' ')[0];
    const dateString = now.toISOString().split('T')[0];
    
    const newAttendance: Attendance = {
      id: Date.now().toString(),
      userId: user?.id || '',
      date: dateString,
      checkIn: timeString,
      status: now.getHours() > 9 ? 'Late' : 'Present',
      workingHours: 0
    };

    setAttendanceHistory([newAttendance, ...attendanceHistory]);
    setTodayAttendance(newAttendance);
    setIsCheckedIn(true);
  };

  const handleCheckOut = () => {
    if (todayAttendance) {
      const now = new Date();
      const timeString = now.toTimeString().split(' ')[0];
      
      const checkInTime = new Date(`2000-01-01 ${todayAttendance.checkIn}`);
      const checkOutTime = new Date(`2000-01-01 ${timeString}`);
      const workingHours = (checkOutTime.getTime() - checkInTime.getTime()) / (1000 * 60 * 60);

      const updatedAttendance = {
        ...todayAttendance,
        checkOut: timeString,
        workingHours: Math.round(workingHours * 100) / 100
      };

      setAttendanceHistory(prev => 
        prev.map(record => 
          record.id === todayAttendance.id ? updatedAttendance : record
        )
      );
      setTodayAttendance(updatedAttendance);
      setIsCheckedIn(false);
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'Present': return 'text-green-600 bg-green-100';
      case 'Late': return 'text-orange-600 bg-orange-100';
      case 'Absent': return 'text-red-600 bg-red-100';
      default: return 'text-gray-600 bg-gray-100';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'Present': return <CheckCircle className="w-4 h-4" />;
      case 'Late': return <AlertCircle className="w-4 h-4" />;
      case 'Absent': return <XCircle className="w-4 h-4" />;
      default: return <Clock className="w-4 h-4" />;
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-bold text-gray-900 flex items-center">
          <Clock className="w-6 h-6 mr-2" />
          {user?.role === 'manager' ? 'সকল স্টাফের উপস্থিতি' : 'আমার উপস্থিতি'}
        </h1>
        <p className="text-gray-600 mt-1">
          {user?.role === 'manager' 
            ? 'সকল স্টাফের উপস্থিতি ট্র্যাক করুন' 
            : 'আপনার উপস্থিতি রেকর্ড করুন এবং ইতিহাস দেখুন'
          }
        </p>
      </div>

      {/* Current Time & Check-in/out for Staff */}
      {user?.role === 'staff' && (
        <div className="bg-gradient-to-r from-blue-600 to-blue-800 rounded-lg p-6 text-white">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <div>
              <h2 className="text-xl font-semibold mb-2">বর্তমান সময়</h2>
              <p className="text-2xl font-bold">
                {currentTime.toLocaleTimeString('bn-BD', { 
                  hour12: true,
                  hour: '2-digit',
                  minute: '2-digit',
                  second: '2-digit'
                })}
              </p>
              <p className="text-blue-100">
                {currentTime.toLocaleDateString('bn-BD', { 
                  weekday: 'long',
                  year: 'numeric',
                  month: 'long',
                  day: 'numeric'
                })}
              </p>
            </div>
            
            <div className="mt-4 md:mt-0">
              {!isCheckedIn ? (
                <button
                  onClick={handleCheckIn}
                  className="bg-green-600 hover:bg-green-700 text-white px-6 py-3 rounded-lg flex items-center font-semibold transition-colors"
                >
                  <PlayCircle className="w-5 h-5 mr-2" />
                  চেক-ইন করুন
                </button>
              ) : (
                <button
                  onClick={handleCheckOut}
                  className="bg-red-600 hover:bg-red-700 text-white px-6 py-3 rounded-lg flex items-center font-semibold transition-colors"
                >
                  <PauseCircle className="w-5 h-5 mr-2" />
                  চেক-আউট করুন
                </button>
              )}
            </div>
          </div>

          {todayAttendance && (
            <div className="mt-4 pt-4 border-t border-blue-500">
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-center">
                <div>
                  <p className="text-blue-100 text-sm">চেক-ইন</p>
                  <p className="font-semibold">{todayAttendance.checkIn || '--:--'}</p>
                </div>
                <div>
                  <p className="text-blue-100 text-sm">চেক-আউট</p>
                  <p className="font-semibold">{todayAttendance.checkOut || '--:--'}</p>
                </div>
                <div>
                  <p className="text-blue-100 text-sm">কাজের সময়</p>
                  <p className="font-semibold">{todayAttendance.workingHours?.toFixed(2) || '0.00'}h</p>
                </div>
                <div>
                  <p className="text-blue-100 text-sm">স্ট্যাটাস</p>
                  <p className="font-semibold">{todayAttendance.status}</p>
                </div>
              </div>
            </div>
          )}
        </div>
      )}

      {/* Today's Staff Status for Managers */}
      {user?.role === 'manager' && (
        <div className="bg-white rounded-lg shadow-sm border border-gray-200">
          <div className="p-6 border-b border-gray-200">
            <h2 className="text-lg font-semibold text-gray-900 flex items-center">
              <Users className="w-5 h-5 mr-2" />
              আজকের স্টাফ স্ট্যাটাস
            </h2>
          </div>
          <div className="p-6">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {allStaffAttendance.map((record) => (
                <div key={record.id} className="p-4 border border-gray-200 rounded-lg">
                  <div className="flex items-center justify-between mb-2">
                    <h4 className="font-medium text-gray-900">{record.staffName}</h4>
                    <span className={`px-2 py-1 text-xs rounded-full flex items-center ${getStatusColor(record.status)}`}>
                      {getStatusIcon(record.status)}
                      <span className="ml-1">{record.status}</span>
                    </span>
                  </div>
                  <div className="text-sm text-gray-600 space-y-1">
                    <p>চেক-ইন: {record.checkIn || '--:--'}</p>
                    <p>চেক-আউট: {record.checkOut || '--:--'}</p>
                    {record.workingHours > 0 && (
                      <p>কাজের সময়: {record.workingHours.toFixed(2)}h</p>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Attendance History */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-200">
        <div className="p-6 border-b border-gray-200">
          <h2 className="text-lg font-semibold text-gray-900 flex items-center">
            <Calendar className="w-5 h-5 mr-2" />
            উপস্থিতির ইতিহাস
          </h2>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  তারিখ
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  চেক-ইন
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  চেক-আউট
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  কাজের সময়
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  স্ট্যাটাস
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {attendanceHistory.map((record) => (
                <tr key={record.id} className="hover:bg-gray-50">
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                    {new Date(record.date).toLocaleDateString('bn-BD')}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                    {record.checkIn || '--:--'}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                    {record.checkOut || '--:--'}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                    {record.workingHours ? `${record.workingHours.toFixed(2)}h` : '--'}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className={`px-2 py-1 text-xs rounded-full flex items-center w-fit ${getStatusColor(record.status)}`}>
                      {getStatusIcon(record.status)}
                      <span className="ml-1">{record.status}</span>
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
import React, { useState } from 'react';
import { 
  DollarSign, 
  Plus, 
  TrendingUp, 
  TrendingDown, 
  Calendar,
  PieChart,
  BarChart3
} from 'lucide-react';
import { Financial } from '../../types';

export const FinanceManagement: React.FC = () => {
  const [showAddForm, setShowAddForm] = useState(false);
  const [selectedType, setSelectedType] = useState<'income' | 'expense'>('income');

  const [financials, setFinancials] = useState<Financial[]>([
    {
      id: '1',
      type: 'income',
      amount: 150000,
      description: 'ওয়েব ডেভেলপমেন্ট প্রজেক্ট',
      date: '2025-01-28',
      category: 'প্রজেক্ট আয়',
      recordedBy: '1'
    },
    {
      id: '2',
      type: 'expense',
      amount: 25000,
      description: 'অফিস ভাড়া',
      date: '2025-01-25',
      category: 'অফিস খরচ',
      recordedBy: '1'
    },
    {
      id: '3',
      type: 'income',
      amount: 80000,
      description: 'গ্রাফিক্স ডিজাইন সার্ভিস',
      date: '2025-01-20',
      category: 'সার্ভিস আয়',
      recordedBy: '1'
    },
    {
      id: '4',
      type: 'expense',
      amount: 15000,
      description: 'ইন্টারনেট ও ইউটিলিটি',
      date: '2025-01-15',
      category: 'ইউটিলিটি',
      recordedBy: '1'
    },
    {
      id: '5',
      type: 'expense',
      amount: 120000,
      description: 'স্টাফ বেতন',
      date: '2025-01-10',
      category: 'বেতন',
      recordedBy: '1'
    }
  ]);

  const [newTransaction, setNewTransaction] = useState({
    type: 'income' as 'income' | 'expense',
    amount: '',
    description: '',
    category: '',
    date: new Date().toISOString().split('T')[0]
  });

  const incomeCategories = [
    'প্রজেক্ট আয়',
    'সার্ভিস আয়',
    'কনসালটেশন',
    'অন্যান্য আয়'
  ];

  const expenseCategories = [
    'অফিস খরচ',
    'বেতন',
    'ইউটিলিটি',
    'মার্কেটিং',
    'যন্ত্রপাতি',
    'অন্যান্য খরচ'
  ];

  const totalIncome = financials
    .filter(f => f.type === 'income')
    .reduce((sum, f) => sum + f.amount, 0);

  const totalExpense = financials
    .filter(f => f.type === 'expense')
    .reduce((sum, f) => sum + f.amount, 0);

  const netProfit = totalIncome - totalExpense;

  const handleAddTransaction = (e: React.FormEvent) => {
    e.preventDefault();
    const transaction: Financial = {
      id: Date.now().toString(),
      ...newTransaction,
      amount: parseFloat(newTransaction.amount),
      recordedBy: '1' // Current user ID
    };
    setFinancials([transaction, ...financials]);
    setNewTransaction({
      type: 'income',
      amount: '',
      description: '',
      category: '',
      date: new Date().toISOString().split('T')[0]
    });
    setShowAddForm(false);
  };

  const getIncomeByCategory = () => {
    const categoryTotals: { [key: string]: number } = {};
    financials
      .filter(f => f.type === 'income')
      .forEach(f => {
        categoryTotals[f.category] = (categoryTotals[f.category] || 0) + f.amount;
      });
    return Object.entries(categoryTotals);
  };

  const getExpenseByCategory = () => {
    const categoryTotals: { [key: string]: number } = {};
    financials
      .filter(f => f.type === 'expense')
      .forEach(f => {
        categoryTotals[f.category] = (categoryTotals[f.category] || 0) + f.amount;
      });
    return Object.entries(categoryTotals);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-2xl font-bold text-gray-900 flex items-center">
            <DollarSign className="w-6 h-6 mr-2" />
            আর্থিক ব্যবস্থাপনা
          </h1>
          <p className="text-gray-600 mt-1">আয়-ব্যয়ের হিসাব রাখুন এবং আর্থিক রিপোর্ট দেখুন</p>
        </div>
        <button
          onClick={() => setShowAddForm(true)}
          className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg flex items-center transition-colors"
        >
          <Plus className="w-4 h-4 mr-2" />
          নতুন লেনদেন যুক্ত করুন
        </button>
      </div>

      {/* Financial Summary */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-gradient-to-r from-green-500 to-green-600 rounded-lg p-6 text-white">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-green-100 text-sm">মোট আয়</p>
              <p className="text-2xl font-bold">৳{totalIncome.toLocaleString()}</p>
            </div>
            <TrendingUp className="w-8 h-8 text-green-200" />
          </div>
        </div>

        <div className="bg-gradient-to-r from-red-500 to-red-600 rounded-lg p-6 text-white">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-red-100 text-sm">মোট ব্যয়</p>
              <p className="text-2xl font-bold">৳{totalExpense.toLocaleString()}</p>
            </div>
            <TrendingDown className="w-8 h-8 text-red-200" />
          </div>
        </div>

        <div className={`bg-gradient-to-r ${netProfit >= 0 ? 'from-blue-500 to-blue-600' : 'from-orange-500 to-orange-600'} rounded-lg p-6 text-white`}>
          <div className="flex items-center justify-between">
            <div>
              <p className="text-blue-100 text-sm">নিট {netProfit >= 0 ? 'লাভ' : 'ক্ষতি'}</p>
              <p className="text-2xl font-bold">৳{Math.abs(netProfit).toLocaleString()}</p>
            </div>
            <BarChart3 className="w-8 h-8 text-blue-200" />
          </div>
        </div>
      </div>

      {/* Add Transaction Form Modal */}
      {showAddForm && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-lg p-6 w-full max-w-md max-h-[90vh] overflow-y-auto">
            <h2 className="text-xl font-bold mb-4">নতুন লেনদেন যুক্ত করুন</h2>
            <form onSubmit={handleAddTransaction} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">ধরন</label>
                <select
                  value={newTransaction.type}
                  onChange={(e) => setNewTransaction({...newTransaction, type: e.target.value as 'income' | 'expense'})}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                >
                  <option value="income">আয়</option>
                  <option value="expense">ব্যয়</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">পরিমাণ (৳)</label>
                <input
                  type="number"
                  required
                  value={newTransaction.amount}
                  onChange={(e) => setNewTransaction({...newTransaction, amount: e.target.value})}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">বিবরণ</label>
                <input
                  type="text"
                  required
                  value={newTransaction.description}
                  onChange={(e) => setNewTransaction({...newTransaction, description: e.target.value})}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">ক্যাটেগরি</label>
                <select
                  required
                  value={newTransaction.category}
                  onChange={(e) => setNewTransaction({...newTransaction, category: e.target.value})}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                >
                  <option value="">ক্যাটেগরি নির্বাচন করুন</option>
                  {(newTransaction.type === 'income' ? incomeCategories : expenseCategories).map(category => (
                    <option key={category} value={category}>{category}</option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">তারিখ</label>
                <input
                  type="date"
                  required
                  value={newTransaction.date}
                  onChange={(e) => setNewTransaction({...newTransaction, date: e.target.value})}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
              </div>
              <div className="flex gap-3 pt-4">
                <button
                  type="submit"
                  className="flex-1 bg-blue-600 hover:bg-blue-700 text-white py-2 px-4 rounded-lg transition-colors"
                >
                  যুক্ত করুন
                </button>
                <button
                  type="button"
                  onClick={() => setShowAddForm(false)}
                  className="flex-1 bg-gray-300 hover:bg-gray-400 text-gray-700 py-2 px-4 rounded-lg transition-colors"
                >
                  বাতিল
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Category Analysis */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Income by Category */}
        <div className="bg-white rounded-lg shadow-sm border border-gray-200">
          <div className="p-6 border-b border-gray-200">
            <h2 className="text-lg font-semibold text-gray-900 flex items-center">
              <PieChart className="w-5 h-5 mr-2 text-green-600" />
              ক্যাটেগরি অনুযায়ী আয়
            </h2>
          </div>
          <div className="p-6">
            <div className="space-y-4">
              {getIncomeByCategory().map(([category, amount]) => (
                <div key={category} className="flex items-center justify-between">
                  <span className="text-sm text-gray-600">{category}</span>
                  <span className="font-semibold text-green-600">৳{amount.toLocaleString()}</span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Expense by Category */}
        <div className="bg-white rounded-lg shadow-sm border border-gray-200">
          <div className="p-6 border-b border-gray-200">
            <h2 className="text-lg font-semibold text-gray-900 flex items-center">
              <PieChart className="w-5 h-5 mr-2 text-red-600" />
              ক্যাটেগরি অনুযায়ী ব্যয়
            </h2>
          </div>
          <div className="p-6">
            <div className="space-y-4">
              {getExpenseByCategory().map(([category, amount]) => (
                <div key={category} className="flex items-center justify-between">
                  <span className="text-sm text-gray-600">{category}</span>
                  <span className="font-semibold text-red-600">৳{amount.toLocaleString()}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Recent Transactions */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-200">
        <div className="p-6 border-b border-gray-200 flex items-center justify-between">
          <h2 className="text-lg font-semibold text-gray-900">সাম্প্রতিক লেনদেন</h2>
          <div className="flex gap-2">
            <button
              onClick={() => setSelectedType('income')}
              className={`px-3 py-1 text-sm rounded-lg transition-colors ${
                selectedType === 'income' 
                  ? 'bg-green-100 text-green-700' 
                  : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
              }`}
            >
              আয়
            </button>
            <button
              onClick={() => setSelectedType('expense')}
              className={`px-3 py-1 text-sm rounded-lg transition-colors ${
                selectedType === 'expense' 
                  ? 'bg-red-100 text-red-700' 
                  : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
              }`}
            >
              ব্যয়
            </button>
          </div>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  তারিখ
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  বিবরণ
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  ক্যাটেগরি
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  পরিমাণ
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {financials
                .filter(f => f.type === selectedType)
                .slice(0, 10)
                .map((transaction) => (
                <tr key={transaction.id} className="hover:bg-gray-50">
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                    <div className="flex items-center">
                      <Calendar className="w-4 h-4 mr-2 text-gray-400" />
                      {new Date(transaction.date).toLocaleDateString('bn-BD')}
                    </div>
                  </td>
                  <td className="px-6 py-4 text-sm text-gray-900">
                    {transaction.description}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-600">
                    {transaction.category}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-semibold">
                    <span className={transaction.type === 'income' ? 'text-green-600' : 'text-red-600'}>
                      {transaction.type === 'income' ? '+' : '-'}৳{transaction.amount.toLocaleString()}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
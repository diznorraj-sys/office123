import React, { useState } from 'react';
import { 
  FileText, 
  Plus, 
  Calendar, 
  User,
  CheckCircle,
  Clock,
  Eye,
  MessageSquare
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { WorkSubmission } from '../../types';

export const WorkSubmissionManager: React.FC = () => {
  const { user } = useAuth();
  const [showAddForm, setShowAddForm] = useState(false);

  const [submissions, setSubmissions] = useState<WorkSubmission[]>([
    {
      id: '1',
      userId: '2',
      title: 'ওয়েবসাইট ডিজাইন প্রোটোটাইপ',
      description: 'নতুন কোম্পানি ওয়েবসাইটের জন্য UI/UX ডিজাইন প্রোটোটাইপ তৈরি করেছি। Figma ফাইল এবং ডিজাইন গাইডলাইন সংযুক্ত করা হয়েছে।',
      submissionDate: '2025-01-28',
      status: 'Submitted',
      reviewedBy: undefined,
      feedback: undefined
    },
    {
      id: '2',
      userId: '3',
      title: 'ডেটাবেস অপ্টিমাইজেশন রিপোর্ট',
      description: 'ডেটাবেস কোয়েরি অপ্টিমাইজেশনের কাজ সম্পন্ন করেছি। পারফরম্যান্স ৪০% উন্নতি হয়েছে।',
      submissionDate: '2025-01-26',
      status: 'Reviewed',
      reviewedBy: '1',
      feedback: 'চমৎকার কাজ! পারফরম্যান্স উন্নতি দেখে খুশি হয়েছি।'
    },
    {
      id: '3',
      userId: '2',
      title: 'মোবাইল অ্যাপ টেস্টিং',
      description: 'নতুন মোবাইল অ্যাপের সকল ফিচার টেস্ট করেছি এবং বাগ রিপোর্ট তৈরি করেছি।',
      submissionDate: '2025-01-24',
      status: 'In Progress',
      reviewedBy: '1',
      feedback: 'কিছু অতিরিক্ত টেস্ট কেস যুক্ত করুন।'
    }
  ]);

  const [newSubmission, setNewSubmission] = useState({
    title: '',
    description: ''
  });

  const staffList = [
    { id: '2', name: 'ফাতিমা আহমেদ' },
    { id: '3', name: 'রহিম উদ্দিন' },
    { id: '4', name: 'সারা খাতুন' }
  ];

  const userSubmissions = user?.role === 'staff' 
    ? submissions.filter(submission => submission.userId === user.id)
    : submissions;

  const handleAddSubmission = (e: React.FormEvent) => {
    e.preventDefault();
    const submission: WorkSubmission = {
      id: Date.now().toString(),
      userId: user?.id || '',
      ...newSubmission,
      submissionDate: new Date().toISOString().split('T')[0],
      status: 'Submitted'
    };
    setSubmissions([submission, ...submissions]);
    setNewSubmission({ title: '', description: '' });
    setShowAddForm(false);
  };

  const handleReviewSubmission = (submissionId: string, status: 'Reviewed' | 'In Progress', feedback: string) => {
    setSubmissions(submissions.map(submission =>
      submission.id === submissionId
        ? {
            ...submission,
            status,
            reviewedBy: user?.id,
            feedback
          }
        : submission
    ));
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'Reviewed': return 'text-green-600 bg-green-100';
      case 'In Progress': return 'text-blue-600 bg-blue-100';
      case 'Submitted': return 'text-orange-600 bg-orange-100';
      default: return 'text-gray-600 bg-gray-100';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'Reviewed': return <CheckCircle className="w-4 h-4" />;
      case 'In Progress': return <Clock className="w-4 h-4" />;
      case 'Submitted': return <FileText className="w-4 h-4" />;
      default: return <FileText className="w-4 h-4" />;
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-2xl font-bold text-gray-900 flex items-center">
            <FileText className="w-6 h-6 mr-2" />
            {user?.role === 'manager' ? 'কাজের জমা ব্যবস্থাপনা' : 'আমার কাজের জমা'}
          </h1>
          <p className="text-gray-600 mt-1">
            {user?.role === 'manager' 
              ? 'স্টাফদের জমা দেওয়া কাজ পর্যালোচনা করুন'
              : 'আপনার সম্পন্ন কাজ জমা দিন এবং ফিডব্যাক দেখুন'
            }
          </p>
        </div>
        {user?.role === 'staff' && (
          <button
            onClick={() => setShowAddForm(true)}
            className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg flex items-center transition-colors"
          >
            <Plus className="w-4 h-4 mr-2" />
            নতুন কাজ জমা দিন
          </button>
        )}
      </div>

      {/* Add Submission Form Modal */}
      {showAddForm && user?.role === 'staff' && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-lg p-6 w-full max-w-md max-h-[90vh] overflow-y-auto">
            <h2 className="text-xl font-bold mb-4">নতুন কাজ জমা দিন</h2>
            <form onSubmit={handleAddSubmission} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">কাজের শিরোনাম</label>
                <input
                  type="text"
                  required
                  value={newSubmission.title}
                  onChange={(e) => setNewSubmission({...newSubmission, title: e.target.value})}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  placeholder="কাজের শিরোনাম লিখুন"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">কাজের বিবরণ</label>
                <textarea
                  required
                  value={newSubmission.description}
                  onChange={(e) => setNewSubmission({...newSubmission, description: e.target.value})}
                  rows={5}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  placeholder="কাজের বিস্তারিত বিবরণ লিখুন..."
                />
              </div>
              <div className="flex gap-3 pt-4">
                <button
                  type="submit"
                  className="flex-1 bg-blue-600 hover:bg-blue-700 text-white py-2 px-4 rounded-lg transition-colors"
                >
                  জমা দিন
                </button>
                <button
                  type="button"
                  onClick={() => setShowAddForm(false)}
                  className="flex-1 bg-gray-300 hover:bg-gray-400 text-gray-700 py-2 px-4 rounded-lg transition-colors"
                >
                  বাতিল
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Submissions List */}
      <div className="space-y-4">
        {userSubmissions.map((submission) => {
          const staffMember = staffList.find(staff => staff.id === submission.userId);
          
          return (
            <div key={submission.id} className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
              <div className="flex items-start justify-between mb-4">
                <div className="flex-1">
                  <div className="flex items-center gap-3 mb-2">
                    <h3 className="text-lg font-semibold text-gray-900">{submission.title}</h3>
                    <span className={`px-2 py-1 text-xs rounded-full flex items-center ${getStatusColor(submission.status)}`}>
                      {getStatusIcon(submission.status)}
                      <span className="ml-1">{submission.status}</span>
                    </span>
                  </div>
                  {user?.role === 'manager' && (
                    <div className="flex items-center text-sm text-gray-600 mb-2">
                      <User className="w-4 h-4 mr-2" />
                      <span>{staffMember?.name}</span>
                    </div>
                  )}
                  <p className="text-gray-700 leading-relaxed mb-3">{submission.description}</p>
                </div>
              </div>

              <div className="flex items-center justify-between text-sm text-gray-500 mb-4">
                <div className="flex items-center">
                  <Calendar className="w-4 h-4 mr-2" />
                  <span>জমা দেওয়ার তারিখ: {new Date(submission.submissionDate).toLocaleDateString('bn-BD')}</span>
                </div>
              </div>

              {/* Feedback Section */}
              {submission.feedback && (
                <div className="bg-gray-50 rounded-lg p-4 mb-4">
                  <div className="flex items-center mb-2">
                    <MessageSquare className="w-4 h-4 mr-2 text-blue-600" />
                    <span className="font-medium text-gray-900">ফিডব্যাক:</span>
                  </div>
                  <p className="text-gray-700">{submission.feedback}</p>
                </div>
              )}

              {/* Manager Actions */}
              {user?.role === 'manager' && submission.status === 'Submitted' && (
                <div className="flex gap-2 pt-4 border-t border-gray-200">
                  <button
                    onClick={() => {
                      const feedback = prompt('ফিডব্যাক লিখুন:');
                      if (feedback) {
                        handleReviewSubmission(submission.id, 'Reviewed', feedback);
                      }
                    }}
                    className="flex-1 bg-green-600 hover:bg-green-700 text-white py-2 px-3 rounded-lg text-sm transition-colors"
                  >
                    অনুমোদন ও ফিডব্যাক
                  </button>
                  <button
                    onClick={() => {
                      const feedback = prompt('কী পরিবর্তন প্রয়োজন?');
                      if (feedback) {
                        handleReviewSubmission(submission.id, 'In Progress', feedback);
                      }
                    }}
                    className="flex-1 bg-blue-600 hover:bg-blue-700 text-white py-2 px-3 rounded-lg text-sm transition-colors"
                  >
                    পুনর্বিবেচনার জন্য পাঠান
                  </button>
                </div>
              )}
            </div>
          );
        })}
      </div>

      {userSubmissions.length === 0 && (
        <div className="text-center py-12">
          <FileText className="w-12 h-12 text-gray-400 mx-auto mb-4" />
          <p className="text-gray-600">কোন কাজের জমা পাওয়া যায়নি</p>
        </div>
      )}
    </div>
  );
};
import React from 'react';
import {
  Home,
  Users,
  Clock,
  Calendar,
  DollarSign,
  FileText,
  BarChart3,
  MessageSquare,
  Settings,
  CheckSquare,
  Palette
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';

interface SidebarProps {
  isOpen: boolean;
  currentPage: string;
  setCurrentPage: (page: string) => void;
}

export const Sidebar: React.FC<SidebarProps> = ({ isOpen, currentPage, setCurrentPage }) => {
  const { user } = useAuth();

  const managerNavItems = [
    { id: 'dashboard', label: 'ড্যাশবোর্ড', icon: Home },
    { id: 'staff', label: 'স্টাফ ম্যানেজমেন্ট', icon: Users },
    { id: 'attendance', label: 'উপস্থিতি', icon: Clock },
    { id: 'leaves', label: 'ছুটির আবেদন', icon: Calendar },
    { id: 'tasks', label: 'টাস্ক ম্যানেজমেন্ট', icon: CheckSquare },
    { id: 'finance', label: 'আর্থিক ব্যবস্থাপনা', icon: DollarSign },
    { id: 'reports', label: 'রিপোর্ট', icon: BarChart3 },
    { id: 'notices', label: 'নোটিশ বোর্ড', icon: MessageSquare },
    { id: 'design-submit', label: 'ডিজাইন সাবমিট', icon: Palette },
    { id: 'settings', label: 'সেটিংস', icon: Settings }
  ];

  const staffNavItems = [
    { id: 'dashboard', label: 'ড্যাশবোর্ড', icon: Home },
    { id: 'attendance', label: 'আমার উপস্থিতি', icon: Clock },
    { id: 'leaves', label: 'ছুটির আবেদন', icon: Calendar },
    { id: 'tasks', label: 'আমার টাস্ক', icon: CheckSquare },
    { id: 'work-submissions', label: 'কাজের জমা', icon: FileText },
    { id: 'design-submit', label: 'ডিজাইন সাবমিট', icon: Palette },
    { id: 'profile', label: 'প্রোফাইল', icon: Users },
    { id: 'notices', label: 'নোটিশ', icon: MessageSquare }
  ];

  const navItems = user?.role === 'manager' ? managerNavItems : staffNavItems;

  return (
    <>
      {/* Mobile backdrop */}
      {isOpen && (
        <div 
          className="fixed inset-0 bg-gray-600 bg-opacity-50 lg:hidden z-40"
          onClick={() => {}}
        />
      )}

      {/* Sidebar */}
      <div className={`
        fixed top-0 left-0 z-40 w-64 h-screen pt-20 transition-transform bg-white border-r border-gray-200
        ${isOpen ? 'translate-x-0' : '-translate-x-full'}
        lg:translate-x-0 lg:static lg:inset-0
      `}>
        <div className="h-full px-3 pb-4 overflow-y-auto bg-white">
          <ul className="space-y-2">
            {navItems.map((item) => {
              const Icon = item.icon;
              return (
                <li key={item.id}>
                  <button
                    onClick={() => setCurrentPage(item.id)}
                    className={`
                      flex items-center w-full p-2 rounded-lg transition-colors
                      ${currentPage === item.id 
                        ? 'bg-blue-100 text-blue-700' 
                        : 'text-gray-900 hover:bg-gray-100'
                      }
                    `}
                  >
                    <Icon size={20} className="mr-3" />
                    {item.label}
                  </button>
                </li>
              );
            })}
          </ul>
        </div>
      </div>
    </>
  );
};
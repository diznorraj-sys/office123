import React, { useState } from 'react';
import { 
  Building2, 
  Users, 
  Clock, 
  BarChart3, 
  CheckCircle, 
  Star,
  Phone,
  Mail,
  MapPin
} from 'lucide-react';
import { LoginForm } from './Auth/LoginForm';
import { SignupForm } from './Auth/SignupForm';

export const LandingPage: React.FC = () => {
  const [showAuth, setShowAuth] = useState(false);
  const [isLogin, setIsLogin] = useState(true);

  const features = [
    {
      icon: Users,
      title: 'স্টাফ ম্যানেজমেন্ট',
      description: 'সহজে স্টাফদের তথ্য পরিচালনা করুন এবং তাদের কার্যক্রম ট্র্যাক করুন।'
    },
    {
      icon: Clock,
      title: 'সময় ও উপস্থিতি',
      description: 'ডিজিটাল চেক-ইন/আউট সিস্টেম এবং স্বয়ংক্রিয় উপস্থিতি ট্র্যাকিং।'
    },
    {
      icon: BarChart3,
      title: 'আর্থিক ব্যবস্থাপনা',
      description: 'আয়-ব্যয়ের হিসাব রাখুন এবং আর্থিক রিপোর্ট তৈরি করুন।'
    },
    {
      icon: CheckCircle,
      title: 'টাস্ক ম্যানেজমেন্ট',
      description: 'কাজ বরাদ্দ করুন, অগ্রগতি ট্র্যাক করুন এবং রিয়েল-টাইম আপডেট পান।'
    }
  ];

  const testimonials = [
    {
      name: 'মোহাম্মদ রহমান',
      position: 'জেনারেল ম্যানেজার',
      company: 'টেক সলিউশন লিমিটেড',
      feedback: 'এই সিস্টেমটি আমাদের অফিস ব্যবস্থাপনাকে অনেক সহজ করে দিয়েছে।',
      rating: 5
    },
    {
      name: 'ফাতিমা আক্তার',
      position: 'এইচআর ম্যানেজার',
      company: 'বিজনেস এন্টারপ্রাইজ',
      feedback: 'স্টাফদের উপস্থিতি এবং কাজের ট্র্যাকিং খুবই কার্যকর।',
      rating: 5
    }
  ];

  if (showAuth) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 py-12 px-4">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-8">
            <button
              onClick={() => setShowAuth(false)}
              className="text-blue-600 hover:text-blue-700 font-medium mb-4"
            >
              ← হোম পেজে ফিরে যান
            </button>
          </div>
          {isLogin ? (
            <LoginForm onToggleForm={() => setIsLogin(false)} />
          ) : (
            <SignupForm onToggleForm={() => setIsLogin(true)} />
          )}
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen">
      {/* Header */}
      <header className="bg-white shadow-sm sticky top-0 z-50">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-4">
            <div className="flex items-center space-x-3">
              <Building2 className="w-8 h-8 text-blue-600" />
              <h1 className="text-xl font-bold text-gray-900">অফিস ম্যানেজমেন্ট সিস্টেম</h1>
            </div>
            <button
              onClick={() => {
                setShowAuth(true);
                setIsLogin(true);
              }}
              className="bg-blue-600 hover:bg-blue-700 text-white px-6 py-2 rounded-lg font-medium transition-colors"
            >
              লগইন করুন
            </button>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="bg-gradient-to-r from-blue-600 to-blue-800 text-white py-20">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h2 className="text-4xl md:text-5xl font-bold mb-6">
              আধুনিক অফিস ব্যবস্থাপনার
              <span className="block text-blue-200">সম্পূর্ণ সমাধান</span>
            </h2>
            <p className="text-xl text-blue-100 mb-8 max-w-3xl mx-auto">
              স্টাফ ম্যানেজমেন্ট, উপস্থিতি ট্র্যাকিং, আর্থিক ব্যবস্থাপনা এবং টাস্ক ম্যানেজমেন্ট - 
              সবকিছু এক জায়গায়। আপনার অফিসের দক্ষতা বাড়ান আজই।
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <button
                onClick={() => {
                  setShowAuth(true);
                  setIsLogin(false);
                }}
                className="bg-white text-blue-600 px-8 py-3 rounded-lg font-semibold hover:bg-blue-50 transition-colors"
              >
                ফ্রি অ্যাকাউন্ট তৈরি করুন
              </button>
              <button
                onClick={() => {
                  setShowAuth(true);
                  setIsLogin(true);
                }}
                className="border-2 border-white text-white px-8 py-3 rounded-lg font-semibold hover:bg-white hover:text-blue-600 transition-colors"
              >
                লগইন করুন
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h3 className="text-3xl font-bold text-gray-900 mb-4">
              কেন আমাদের সিস্টেম বেছে নেবেন?
            </h3>
            <p className="text-lg text-gray-600 max-w-2xl mx-auto">
              আধুনিক প্রযুক্তি এবং ব্যবহারকারী-বান্ধব ইন্টারফেসের সাথে 
              আপনার অফিসের সকল প্রয়োজন মেটান।
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {features.map((feature, index) => {
              const Icon = feature.icon;
              return (
                <div key={index} className="bg-white rounded-lg p-6 shadow-sm hover:shadow-md transition-shadow">
                  <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center mb-4">
                    <Icon className="w-6 h-6 text-blue-600" />
                  </div>
                  <h4 className="text-lg font-semibold text-gray-900 mb-2">
                    {feature.title}
                  </h4>
                  <p className="text-gray-600 text-sm">
                    {feature.description}
                  </p>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Testimonials Section */}
      <section className="py-20">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h3 className="text-3xl font-bold text-gray-900 mb-4">
              আমাদের ক্লায়েন্টরা কী বলেন
            </h3>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {testimonials.map((testimonial, index) => (
              <div key={index} className="bg-white rounded-lg p-6 shadow-sm">
                <div className="flex items-center mb-4">
                  {[...Array(testimonial.rating)].map((_, i) => (
                    <Star key={i} className="w-5 h-5 text-yellow-400 fill-current" />
                  ))}
                </div>
                <p className="text-gray-700 mb-4 italic">
                  "{testimonial.feedback}"
                </p>
                <div>
                  <p className="font-semibold text-gray-900">{testimonial.name}</p>
                  <p className="text-sm text-gray-600">{testimonial.position}</p>
                  <p className="text-sm text-gray-500">{testimonial.company}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section className="py-20 bg-gray-900 text-white">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
            <div>
              <h3 className="text-3xl font-bold mb-6">
                আমাদের সাথে যোগাযোগ করুন
              </h3>
              <p className="text-gray-300 mb-8">
                আপনার অফিস ম্যানেজমেন্ট সিস্টেম নিয়ে কোন প্রশ্ন আছে? 
                আমরা আপনাকে সাহায্য করতে প্রস্তুত।
              </p>

              <div className="space-y-4">
                <div className="flex items-center">
                  <Phone className="w-5 h-5 text-blue-400 mr-3" />
                  <span>+৮৮০ ১৭১২ ৩৪৫৬৭৮</span>
                </div>
                <div className="flex items-center">
                  <Mail className="w-5 h-5 text-blue-400 mr-3" />
                  <span>support@officemanagement.com</span>
                </div>
                <div className="flex items-center">
                  <MapPin className="w-5 h-5 text-blue-400 mr-3" />
                  <span>ঢাকা, বাংলাদেশ</span>
                </div>
              </div>
            </div>

            <div>
              <h4 className="text-xl font-semibold mb-6">
                আমাদের মিশন ও ভিশন
              </h4>
              <div className="space-y-6">
                <div>
                  <h5 className="font-semibold text-blue-400 mb-2">আমাদের মিশন</h5>
                  <p className="text-gray-300 text-sm">
                    বাংলাদেশের প্রতিটি অফিসে আধুনিক ম্যানেজমেন্ট সিস্টেম পৌঁছে দেওয়া 
                    এবং কর্মক্ষেত্রের দক্ষতা বৃদ্ধি করা।
                  </p>
                </div>
                <div>
                  <h5 className="font-semibold text-blue-400 mb-2">আমাদের ভিশন</h5>
                  <p className="text-gray-300 text-sm">
                    প্রযুক্তির মাধ্যমে অফিস ব্যবস্থাপনাকে সহজ, দ্রুত এবং কার্যকর করে তোলা।
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-950 text-gray-400 py-8">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <div className="flex items-center space-x-3 mb-4 md:mb-0">
              <Building2 className="w-6 h-6 text-blue-400" />
              <span className="font-semibold">অফিস ম্যানেজমেন্ট সিস্টেম</span>
            </div>
            <p className="text-sm text-center md:text-right">
              © ২০২৫ অফিস ম্যানেজমেন্ট সিস্টেম। সকল অধিকার সংরক্ষিত।
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
};
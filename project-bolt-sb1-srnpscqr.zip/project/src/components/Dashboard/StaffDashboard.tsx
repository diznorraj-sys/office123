import React, { useState } from 'react';
import { 
  Clock, 
  Calendar, 
  CheckSquare, 
  FileText, 
  TrendingUp,
  PlayCircle,
  PauseCircle,
  User
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';

export const StaffDashboard: React.FC = () => {
  const { user } = useAuth();
  const [isWorking, setIsWorking] = useState(false);
  const [todayHours, setTodayHours] = useState(7.5);

  const [stats] = useState({
    attendance: 95,
    tasksCompleted: 23,
    pendingTasks: 5,
    thisMonthSalary: 45000
  });

  const [recentTasks] = useState([
    { id: 1, title: 'ওয়েবসাইট ডিজাইন আপডেট', status: 'In Progress', priority: 'High', deadline: '২০২৫-০১-৩০' },
    { id: 2, title: 'ডেটাবেস অপ্টিমাইজেশন', status: 'Completed', priority: 'Medium', deadline: '২০২৫-০১-২৮' },
    { id: 3, title: 'ক্লায়েন্ট মিটিং প্রস্তুতি', status: 'To Do', priority: 'High', deadline: '২০২৫-০২-০১' }
  ]);

  const handleWorkToggle = () => {
    setIsWorking(!isWorking);
    // In real app, this would start/stop time tracking
  };

  return (
    <div className="space-y-6">
      {/* Welcome Header */}
      <div className="bg-gradient-to-r from-emerald-600 to-emerald-800 rounded-lg p-6 text-white">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold mb-2">স্বাগতম, {user?.name}!</h1>
            <p className="text-emerald-100">আজকের কাজের পরিকল্পনা দেখুন</p>
          </div>
          <div className="text-right">
            <p className="text-sm text-emerald-100">আজ</p>
            <p className="text-xl font-bold">{new Date().toLocaleDateString('bn-BD')}</p>
          </div>
        </div>
      </div>

      {/* Quick Actions */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-semibold text-gray-900">কাজের সময়</h3>
            <Clock className="w-5 h-5 text-gray-600" />
          </div>
          <div className="text-center">
            <p className="text-3xl font-bold text-gray-900 mb-2">{todayHours}h</p>
            <button
              onClick={handleWorkToggle}
              className={`flex items-center justify-center w-full px-4 py-2 rounded-lg font-medium transition-colors ${
                isWorking 
                  ? 'bg-red-600 hover:bg-red-700 text-white' 
                  : 'bg-green-600 hover:bg-green-700 text-white'
              }`}
            >
              {isWorking ? (
                <>
                  <PauseCircle className="w-4 h-4 mr-2" />
                  কাজ বন্ধ করুন
                </>
              ) : (
                <>
                  <PlayCircle className="w-4 h-4 mr-2" />
                  কাজ শুরু করুন
                </>
              )}
            </button>
          </div>
        </div>

        <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-semibold text-gray-900">উপস্থিতি</h3>
            <TrendingUp className="w-5 h-5 text-gray-600" />
          </div>
          <div className="text-center">
            <p className="text-3xl font-bold text-green-600 mb-2">{stats.attendance}%</p>
            <p className="text-sm text-gray-600">এই মাসে</p>
          </div>
        </div>

        <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-semibold text-gray-900">বেতন</h3>
            <User className="w-5 h-5 text-gray-600" />
          </div>
          <div className="text-center">
            <p className="text-2xl font-bold text-blue-600 mb-2">৳{stats.thisMonthSalary.toLocaleString()}</p>
            <p className="text-sm text-gray-600">এই মাসের বেতন</p>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Recent Tasks */}
        <div className="bg-white rounded-lg shadow-sm border border-gray-200">
          <div className="p-6 border-b border-gray-200">
            <h2 className="text-lg font-semibold text-gray-900 flex items-center">
              <CheckSquare className="w-5 h-5 mr-2" />
              আমার টাস্ক
            </h2>
          </div>
          <div className="p-6">
            <div className="space-y-4">
              {recentTasks.map((task) => (
                <div key={task.id} className="p-4 border border-gray-200 rounded-lg">
                  <div className="flex items-center justify-between mb-2">
                    <h4 className="font-medium text-gray-900">{task.title}</h4>
                    <span className={`px-2 py-1 text-xs rounded-full ${
                      task.status === 'Completed' ? 'bg-green-100 text-green-800' :
                      task.status === 'In Progress' ? 'bg-blue-100 text-blue-800' :
                      'bg-gray-100 text-gray-800'
                    }`}>
                      {task.status}
                    </span>
                  </div>
                  <div className="flex items-center justify-between text-sm text-gray-600">
                    <span className={`px-2 py-1 rounded ${
                      task.priority === 'High' ? 'bg-red-100 text-red-700' :
                      task.priority === 'Medium' ? 'bg-yellow-100 text-yellow-700' :
                      'bg-gray-100 text-gray-700'
                    }`}>
                      {task.priority}
                    </span>
                    <span>শেষ তারিখ: {task.deadline}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Performance Summary */}
        <div className="bg-white rounded-lg shadow-sm border border-gray-200">
          <div className="p-6 border-b border-gray-200">
            <h2 className="text-lg font-semibold text-gray-900 flex items-center">
              <FileText className="w-5 h-5 mr-2" />
              কর্মক্ষমতা সংক্ষিপ্তসার
            </h2>
          </div>
          <div className="p-6 space-y-6">
            <div>
              <div className="flex justify-between items-center mb-2">
                <span className="text-sm text-gray-600">সম্পন্ন টাস্ক</span>
                <span className="font-semibold">{stats.tasksCompleted}</span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-2">
                <div className="bg-green-600 h-2 rounded-full" style={{ width: '85%' }}></div>
              </div>
            </div>

            <div>
              <div className="flex justify-between items-center mb-2">
                <span className="text-sm text-gray-600">চলমান টাস্ক</span>
                <span className="font-semibold">{stats.pendingTasks}</span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-2">
                <div className="bg-blue-600 h-2 rounded-full" style={{ width: '60%' }}></div>
              </div>
            </div>

            <div className="pt-4 border-t border-gray-200">
              <div className="grid grid-cols-2 gap-4 text-center">
                <div>
                  <p className="text-2xl font-bold text-blue-600">{stats.tasksCompleted}</p>
                  <p className="text-xs text-gray-600">মোট সম্পন্ন</p>
                </div>
                <div>
                  <p className="text-2xl font-bold text-orange-600">{stats.pendingTasks}</p>
                  <p className="text-xs text-gray-600">বাকি আছে</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
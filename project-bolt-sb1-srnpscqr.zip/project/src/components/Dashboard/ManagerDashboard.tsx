import React, { useState, useEffect } from 'react';
import { 
  Users, 
  Clock, 
  DollarSign, 
  TrendingUp, 
  Calendar,
  CheckSquare,
  AlertCircle,
  Activity
} from 'lucide-react';

export const ManagerDashboard: React.FC = () => {
  const [stats, setStats] = useState({
    totalStaff: 15,
    presentToday: 12,
    totalRevenue: 850000,
    monthlyExpense: 320000,
    pendingLeaves: 3,
    activeTasks: 28,
    completedTasks: 45
  });

  const [recentActivities] = useState([
    { id: 1, action: 'ফাতিমা আহমেদ চেক-ইন করেছে', time: '৯:১৫ AM', type: 'checkin' },
    { id: 2, action: 'রহিম উদ্দিন ছুটির আবেদন করেছে', time: '৮:৪৫ AM', type: 'leave' },
    { id: 3, action: 'সারা খাতুন একটি টাস্ক সম্পন্ন করেছে', time: '৮:৩০ AM', type: 'task' },
    { id: 4, action: 'নতুন প্রজেক্ট তৈরি হয়েছে', time: '৮:০০ AM', type: 'project' }
  ]);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-gradient-to-r from-blue-600 to-blue-800 rounded-lg p-6 text-white">
        <h1 className="text-2xl font-bold mb-2">ম্যানেজার ড্যাশবোর্ড</h1>
        <p className="text-blue-100">আপনার অফিসের সম্পূর্ণ ওভারভিউ</p>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">মোট স্টাফ</p>
              <p className="text-2xl font-bold text-gray-900">{stats.totalStaff}</p>
            </div>
            <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
              <Users className="w-6 h-6 text-blue-600" />
            </div>
          </div>
        </div>

        <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">আজ উপস্থিত</p>
              <p className="text-2xl font-bold text-gray-900">{stats.presentToday}</p>
            </div>
            <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
              <Clock className="w-6 h-6 text-green-600" />
            </div>
          </div>
        </div>

        <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">মাসিক আয়</p>
              <p className="text-2xl font-bold text-gray-900">৳{stats.totalRevenue.toLocaleString()}</p>
            </div>
            <div className="w-12 h-12 bg-emerald-100 rounded-lg flex items-center justify-center">
              <DollarSign className="w-6 h-6 text-emerald-600" />
            </div>
          </div>
        </div>

        <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">অপেক্ষমান ছুটি</p>
              <p className="text-2xl font-bold text-gray-900">{stats.pendingLeaves}</p>
            </div>
            <div className="w-12 h-12 bg-orange-100 rounded-lg flex items-center justify-center">
              <Calendar className="w-6 h-6 text-orange-600" />
            </div>
          </div>
        </div>
      </div>

      {/* Main Content Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Recent Activities */}
        <div className="lg:col-span-2 bg-white rounded-lg shadow-sm border border-gray-200">
          <div className="p-6 border-b border-gray-200">
            <h2 className="text-lg font-semibold text-gray-900 flex items-center">
              <Activity className="w-5 h-5 mr-2" />
              সাম্প্রতিক কার্যকলাপ
            </h2>
          </div>
          <div className="p-6">
            <div className="space-y-4">
              {recentActivities.map((activity) => (
                <div key={activity.id} className="flex items-center p-3 bg-gray-50 rounded-lg">
                  <div className={`w-2 h-2 rounded-full mr-3 ${
                    activity.type === 'checkin' ? 'bg-green-500' :
                    activity.type === 'leave' ? 'bg-orange-500' :
                    activity.type === 'task' ? 'bg-blue-500' : 'bg-purple-500'
                  }`}></div>
                  <div className="flex-1">
                    <p className="text-sm text-gray-900">{activity.action}</p>
                    <p className="text-xs text-gray-500">{activity.time}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Quick Stats */}
        <div className="space-y-6">
          <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">টাস্ক সংক্ষিপ্তসার</h3>
            <div className="space-y-3">
              <div className="flex justify-between items-center">
                <span className="text-sm text-gray-600">সক্রিয় টাস্ক</span>
                <span className="font-semibold text-blue-600">{stats.activeTasks}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-sm text-gray-600">সম্পন্ন টাস্ক</span>
                <span className="font-semibold text-green-600">{stats.completedTasks}</span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-2">
                <div 
                  className="bg-blue-600 h-2 rounded-full" 
                  style={{ width: `${(stats.completedTasks / (stats.activeTasks + stats.completedTasks)) * 100}%` }}
                ></div>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">আর্থিক সংক্ষিপ্তসার</h3>
            <div className="space-y-3">
              <div className="flex justify-between items-center">
                <span className="text-sm text-gray-600">মাসিক আয়</span>
                <span className="font-semibold text-green-600">৳{stats.totalRevenue.toLocaleString()}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-sm text-gray-600">মাসিক ব্যয়</span>
                <span className="font-semibold text-red-600">৳{stats.monthlyExpense.toLocaleString()}</span>
              </div>
              <div className="flex justify-between items-center pt-2 border-t">
                <span className="font-semibold text-gray-900">নিট লাভ</span>
                <span className="font-bold text-emerald-600">৳{(stats.totalRevenue - stats.monthlyExpense).toLocaleString()}</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
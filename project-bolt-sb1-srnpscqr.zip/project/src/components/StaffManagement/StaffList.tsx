import React, { useState } from 'react';
import { 
  Users, 
  Plus, 
  Search, 
  Edit, 
  Trash2, 
  Mail, 
  Phone, 
  MapPin,
  Calendar,
  User
} from 'lucide-react';
import { Staff } from '../../types';

export const StaffList: React.FC = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [showAddForm, setShowAddForm] = useState(false);
  const [editingStaff, setEditingStaff] = useState<Staff | null>(null);

  const [staffList, setStaffList] = useState<Staff[]>([
    {
      id: '2',
      name: 'ফাতিমা আহমেদ',
      email: 'fatima@office.com',
      role: 'staff',
      joinDate: '2023-03-01',
      status: 'active',
      phone: '+880123456790',
      address: 'চট্টগ্রাম, বাংলাদেশ',
      designation: 'সিনিয়র ডেভেলপার',
      department: 'আইটি'
    },
    {
      id: '3',
      name: 'রহিম উদ্দিন',
      email: 'rahim@office.com',
      role: 'staff',
      joinDate: '2023-05-15',
      status: 'active',
      phone: '+880123456791',
      address: 'সিলেট, বাংলাদেশ',
      designation: 'গ্রাফিক্স ডিজাইনার',
      department: 'ডিজাইন'
    },
    {
      id: '4',
      name: 'সারা খাতুন',
      email: 'sara@office.com',
      role: 'staff',
      joinDate: '2023-07-20',
      status: 'active',
      phone: '+880123456792',
      address: 'রাজশাহী, বাংলাদেশ',
      designation: 'অ্যাকাউন্ট্যান্ট',
      department: 'ফিন্যান্স'
    }
  ]);

  const [newStaff, setNewStaff] = useState({
    name: '',
    email: '',
    phone: '',
    address: '',
    designation: '',
    department: ''
  });

  const filteredStaff = staffList.filter(staff =>
    staff.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    staff.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
    staff.designation.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleAddStaff = (e: React.FormEvent) => {
    e.preventDefault();
    const staff: Staff = {
      id: Date.now().toString(),
      ...newStaff,
      role: 'staff',
      joinDate: new Date().toISOString().split('T')[0],
      status: 'active'
    };
    setStaffList([...staffList, staff]);
    setNewStaff({ name: '', email: '', phone: '', address: '', designation: '', department: '' });
    setShowAddForm(false);
  };

  const handleDeleteStaff = (id: string) => {
    if (confirm('আপনি কি নিশ্চিত যে এই স্টাফকে মুছে ফেলতে চান?')) {
      setStaffList(staffList.filter(staff => staff.id !== id));
    }
  };

  const handleEditStaff = (staff: Staff) => {
    setEditingStaff(staff);
    setNewStaff({
      name: staff.name,
      email: staff.email,
      phone: staff.phone || '',
      address: staff.address || '',
      designation: staff.designation || '',
      department: staff.department || ''
    });
    setShowAddForm(true);
  };

  const handleUpdateStaff = (e: React.FormEvent) => {
    e.preventDefault();
    if (editingStaff) {
      const updatedStaff = {
        ...editingStaff,
        ...newStaff
      };
      setStaffList(staffList.map(staff => 
        staff.id === editingStaff.id ? updatedStaff : staff
      ));
      setEditingStaff(null);
      setNewStaff({ name: '', email: '', phone: '', address: '', designation: '', department: '' });
      setShowAddForm(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-2xl font-bold text-gray-900 flex items-center">
            <Users className="w-6 h-6 mr-2" />
            স্টাফ ম্যানেজমেন্ট
          </h1>
          <p className="text-gray-600 mt-1">সকল স্টাফের তথ্য পরিচালনা করুন</p>
        </div>
        <button
          onClick={() => {
            setEditingStaff(null);
            setNewStaff({ name: '', email: '', phone: '', address: '', designation: '', department: '' });
            setShowAddForm(true);
          }}
          className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg flex items-center transition-colors"
        >
          <Plus className="w-4 h-4 mr-2" />
          নতুন স্টাফ যুক্ত করুন
        </button>
      </div>

      {/* Search */}
      <div className="relative">
        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
        <input
          type="text"
          placeholder="স্টাফ খুঁজুন..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
        />
      </div>

      {/* Add/Edit Form Modal */}
      {showAddForm && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-lg p-6 w-full max-w-md max-h-[90vh] overflow-y-auto">
            <h2 className="text-xl font-bold mb-4">
              {editingStaff ? 'স্টাফ তথ্য সম্পাদনা' : 'নতুন স্টাফ যুক্ত করুন'}
            </h2>
            <form onSubmit={editingStaff ? handleUpdateStaff : handleAddStaff} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">নাম</label>
                <input
                  type="text"
                  required
                  value={newStaff.name}
                  onChange={(e) => setNewStaff({...newStaff, name: e.target.value})}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">ইমেল</label>
                <input
                  type="email"
                  required
                  value={newStaff.email}
                  onChange={(e) => setNewStaff({...newStaff, email: e.target.value})}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">ফোন</label>
                <input
                  type="tel"
                  value={newStaff.phone}
                  onChange={(e) => setNewStaff({...newStaff, phone: e.target.value})}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">ঠিকানা</label>
                <input
                  type="text"
                  value={newStaff.address}
                  onChange={(e) => setNewStaff({...newStaff, address: e.target.value})}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">পদবী</label>
                <input
                  type="text"
                  value={newStaff.designation}
                  onChange={(e) => setNewStaff({...newStaff, designation: e.target.value})}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">বিভাগ</label>
                <input
                  type="text"
                  value={newStaff.department}
                  onChange={(e) => setNewStaff({...newStaff, department: e.target.value})}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
              </div>
              <div className="flex gap-3 pt-4">
                <button
                  type="submit"
                  className="flex-1 bg-blue-600 hover:bg-blue-700 text-white py-2 px-4 rounded-lg transition-colors"
                >
                  {editingStaff ? 'আপডেট করুন' : 'যুক্ত করুন'}
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setShowAddForm(false);
                    setEditingStaff(null);
                  }}
                  className="flex-1 bg-gray-300 hover:bg-gray-400 text-gray-700 py-2 px-4 rounded-lg transition-colors"
                >
                  বাতিল
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Staff Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredStaff.map((staff) => (
          <div key={staff.id} className="bg-white rounded-lg shadow-sm border border-gray-200 p-6 hover:shadow-md transition-shadow">
            <div className="flex items-center justify-between mb-4">
              <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center">
                <User className="w-6 h-6 text-blue-600" />
              </div>
              <div className="flex gap-2">
                <button
                  onClick={() => handleEditStaff(staff)}
                  className="p-2 text-gray-400 hover:text-blue-600 hover:bg-blue-50 rounded-lg transition-colors"
                >
                  <Edit className="w-4 h-4" />
                </button>
                <button
                  onClick={() => handleDeleteStaff(staff.id)}
                  className="p-2 text-gray-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </div>

            <div className="space-y-3">
              <div>
                <h3 className="font-semibold text-gray-900">{staff.name}</h3>
                <p className="text-sm text-gray-600">{staff.designation}</p>
              </div>

              <div className="space-y-2 text-sm text-gray-600">
                <div className="flex items-center">
                  <Mail className="w-4 h-4 mr-2" />
                  {staff.email}
                </div>
                {staff.phone && (
                  <div className="flex items-center">
                    <Phone className="w-4 h-4 mr-2" />
                    {staff.phone}
                  </div>
                )}
                {staff.address && (
                  <div className="flex items-center">
                    <MapPin className="w-4 h-4 mr-2" />
                    {staff.address}
                  </div>
                )}
                <div className="flex items-center">
                  <Calendar className="w-4 h-4 mr-2" />
                  যোগদান: {new Date(staff.joinDate).toLocaleDateString('bn-BD')}
                </div>
              </div>

              <div className="flex items-center justify-between pt-3 border-t border-gray-200">
                <span className="text-sm text-gray-600">{staff.department}</span>
                <span className={`px-2 py-1 text-xs rounded-full ${
                  staff.status === 'active' 
                    ? 'bg-green-100 text-green-800' 
                    : 'bg-red-100 text-red-800'
                }`}>
                  {staff.status === 'active' ? 'সক্রিয়' : 'নিষ্ক্রিয়'}
                </span>
              </div>
            </div>
          </div>
        ))}
      </div>

      {filteredStaff.length === 0 && (
        <div className="text-center py-12">
          <Users className="w-12 h-12 text-gray-400 mx-auto mb-4" />
          <p className="text-gray-600">কোন স্টাফ পাওয়া যায়নি</p>
        </div>
      )}
    </div>
  );
};
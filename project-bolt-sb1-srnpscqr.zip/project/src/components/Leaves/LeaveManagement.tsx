import React, { useState } from 'react';
import { 
  Calendar, 
  Plus, 
  Clock, 
  CheckCircle, 
  XCircle, 
  AlertCircle,
  User,
  FileText
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { Leave } from '../../types';

export const LeaveManagement: React.FC = () => {
  const { user } = useAuth();
  const [showAddForm, setShowAddForm] = useState(false);

  const [leaves, setLeaves] = useState<Leave[]>([
    {
      id: '1',
      userId: '2',
      startDate: '2025-02-05',
      endDate: '2025-02-07',
      reason: 'পারিবারিক কাজে',
      status: 'Pending',
      appliedDate: '2025-01-28',
      approvedBy: undefined,
      approvedDate: undefined
    },
    {
      id: '2',
      userId: '3',
      startDate: '2025-01-30',
      endDate: '2025-01-30',
      reason: 'অসুস্থতার কারণে',
      status: 'Approved',
      appliedDate: '2025-01-25',
      approvedBy: '1',
      approvedDate: '2025-01-26'
    },
    {
      id: '3',
      userId: '2',
      startDate: '2025-01-20',
      endDate: '2025-01-22',
      reason: 'ব্যক্তিগত কাজে',
      status: 'Rejected',
      appliedDate: '2025-01-15',
      approvedBy: '1',
      approvedDate: '2025-01-16'
    }
  ]);

  const [newLeave, setNewLeave] = useState({
    startDate: '',
    endDate: '',
    reason: ''
  });

  const staffList = [
    { id: '2', name: 'ফাতিমা আহমেদ' },
    { id: '3', name: 'রহিম উদ্দিন' },
    { id: '4', name: 'সারা খাতুন' }
  ];

  const userLeaves = user?.role === 'staff' 
    ? leaves.filter(leave => leave.userId === user.id)
    : leaves;

  const handleAddLeave = (e: React.FormEvent) => {
    e.preventDefault();
    const leave: Leave = {
      id: Date.now().toString(),
      userId: user?.id || '',
      ...newLeave,
      status: 'Pending',
      appliedDate: new Date().toISOString().split('T')[0]
    };
    setLeaves([leave, ...leaves]);
    setNewLeave({ startDate: '', endDate: '', reason: '' });
    setShowAddForm(false);
  };

  const handleApproveLeave = (leaveId: string) => {
    setLeaves(leaves.map(leave =>
      leave.id === leaveId
        ? {
            ...leave,
            status: 'Approved' as const,
            approvedBy: user?.id,
            approvedDate: new Date().toISOString().split('T')[0]
          }
        : leave
    ));
  };

  const handleRejectLeave = (leaveId: string) => {
    setLeaves(leaves.map(leave =>
      leave.id === leaveId
        ? {
            ...leave,
            status: 'Rejected' as const,
            approvedBy: user?.id,
            approvedDate: new Date().toISOString().split('T')[0]
          }
        : leave
    ));
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'Approved': return 'text-green-600 bg-green-100';
      case 'Rejected': return 'text-red-600 bg-red-100';
      case 'Pending': return 'text-orange-600 bg-orange-100';
      default: return 'text-gray-600 bg-gray-100';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'Approved': return <CheckCircle className="w-4 h-4" />;
      case 'Rejected': return <XCircle className="w-4 h-4" />;
      case 'Pending': return <Clock className="w-4 h-4" />;
      default: return <AlertCircle className="w-4 h-4" />;
    }
  };

  const calculateDays = (startDate: string, endDate: string) => {
    const start = new Date(startDate);
    const end = new Date(endDate);
    const diffTime = Math.abs(end.getTime() - start.getTime());
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24)) + 1;
    return diffDays;
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-2xl font-bold text-gray-900 flex items-center">
            <Calendar className="w-6 h-6 mr-2" />
            {user?.role === 'manager' ? 'ছুটির আবেদন ব্যবস্থাপনা' : 'আমার ছুটির আবেদন'}
          </h1>
          <p className="text-gray-600 mt-1">
            {user?.role === 'manager' 
              ? 'স্টাফদের ছুটির আবেদন পর্যালোচনা ও অনুমোদন করুন'
              : 'ছুটির জন্য আবেদন করুন এবং স্ট্যাটাস দেখুন'
            }
          </p>
        </div>
        {user?.role === 'staff' && (
          <button
            onClick={() => setShowAddForm(true)}
            className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg flex items-center transition-colors"
          >
            <Plus className="w-4 h-4 mr-2" />
            নতুন আবেদন
          </button>
        )}
      </div>

      {/* Add Leave Form Modal */}
      {showAddForm && user?.role === 'staff' && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-lg p-6 w-full max-w-md max-h-[90vh] overflow-y-auto">
            <h2 className="text-xl font-bold mb-4">নতুন ছুটির আবেদন</h2>
            <form onSubmit={handleAddLeave} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">শুরুর তারিখ</label>
                <input
                  type="date"
                  required
                  value={newLeave.startDate}
                  onChange={(e) => setNewLeave({...newLeave, startDate: e.target.value})}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">শেষ তারিখ</label>
                <input
                  type="date"
                  required
                  value={newLeave.endDate}
                  onChange={(e) => setNewLeave({...newLeave, endDate: e.target.value})}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">কারণ</label>
                <textarea
                  required
                  value={newLeave.reason}
                  onChange={(e) => setNewLeave({...newLeave, reason: e.target.value})}
                  rows={3}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  placeholder="ছুটির কারণ লিখুন..."
                />
              </div>
              <div className="flex gap-3 pt-4">
                <button
                  type="submit"
                  className="flex-1 bg-blue-600 hover:bg-blue-700 text-white py-2 px-4 rounded-lg transition-colors"
                >
                  আবেদন জমা দিন
                </button>
                <button
                  type="button"
                  onClick={() => setShowAddForm(false)}
                  className="flex-1 bg-gray-300 hover:bg-gray-400 text-gray-700 py-2 px-4 rounded-lg transition-colors"
                >
                  বাতিল
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Leave Applications */}
      <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-6">
        {userLeaves.map((leave) => {
          const staffMember = staffList.find(staff => staff.id === leave.userId);
          const days = calculateDays(leave.startDate, leave.endDate);
          
          return (
            <div key={leave.id} className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
              <div className="flex items-start justify-between mb-4">
                <div className="flex-1">
                  {user?.role === 'manager' && (
                    <div className="flex items-center mb-2">
                      <User className="w-4 h-4 mr-2 text-gray-600" />
                      <span className="font-medium text-gray-900">{staffMember?.name}</span>
                    </div>
                  )}
                  <div className="flex items-center text-sm text-gray-600 mb-1">
                    <Calendar className="w-4 h-4 mr-2" />
                    {new Date(leave.startDate).toLocaleDateString('bn-BD')} - {new Date(leave.endDate).toLocaleDateString('bn-BD')}
                  </div>
                  <div className="text-sm text-gray-600">
                    <span className="font-medium">{days} দিন</span>
                  </div>
                </div>
                <span className={`px-2 py-1 text-xs rounded-full flex items-center ${getStatusColor(leave.status)}`}>
                  {getStatusIcon(leave.status)}
                  <span className="ml-1">{leave.status}</span>
                </span>
              </div>

              <div className="space-y-3">
                <div>
                  <h4 className="text-sm font-medium text-gray-700 mb-1">কারণ:</h4>
                  <p className="text-sm text-gray-600">{leave.reason}</p>
                </div>

                <div className="text-xs text-gray-500 space-y-1">
                  <p>আবেদনের তারিখ: {new Date(leave.appliedDate).toLocaleDateString('bn-BD')}</p>
                  {leave.approvedDate && (
                    <p>
                      {leave.status === 'Approved' ? 'অনুমোদনের' : 'প্রত্যাখ্যানের'} তারিখ: {new Date(leave.approvedDate).toLocaleDateString('bn-BD')}
                    </p>
                  )}
                </div>

                {/* Manager Actions */}
                {user?.role === 'manager' && leave.status === 'Pending' && (
                  <div className="flex gap-2 pt-3 border-t border-gray-200">
                    <button
                      onClick={() => handleApproveLeave(leave.id)}
                      className="flex-1 bg-green-600 hover:bg-green-700 text-white py-2 px-3 rounded-lg text-sm transition-colors"
                    >
                      অনুমোদন
                    </button>
                    <button
                      onClick={() => handleRejectLeave(leave.id)}
                      className="flex-1 bg-red-600 hover:bg-red-700 text-white py-2 px-3 rounded-lg text-sm transition-colors"
                    >
                      প্রত্যাখ্যান
                    </button>
                  </div>
                )}
              </div>
            </div>
          );
        })}
      </div>

      {userLeaves.length === 0 && (
        <div className="text-center py-12">
          <Calendar className="w-12 h-12 text-gray-400 mx-auto mb-4" />
          <p className="text-gray-600">কোন ছুটির আবেদন পাওয়া যায়নি</p>
        </div>
      )}
    </div>
  );
};
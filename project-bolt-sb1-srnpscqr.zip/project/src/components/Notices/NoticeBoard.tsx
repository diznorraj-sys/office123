import React, { useState } from 'react';
import { 
  MessageSquare, 
  Plus, 
  Calendar, 
  User,
  AlertCircle,
  Info,
  CheckCircle
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { Notice } from '../../types';

export const NoticeBoard: React.FC = () => {
  const { user } = useAuth();
  const [showAddForm, setShowAddForm] = useState(false);

  const [notices, setNotices] = useState<Notice[]>([
    {
      id: '1',
      title: 'অফিস সময়সূচী পরিবর্তন',
      content: 'আগামী সপ্তাহ থেকে অফিসের সময় সকাল ৯টা থেকে সন্ধ্যা ৬টা পর্যন্ত হবে। সবাই সময়মতো উপস্থিত থাকার জন্য অনুরোধ করা হচ্ছে।',
      publishedBy: '1',
      publishedDate: '2025-01-28',
      priority: 'High'
    },
    {
      id: '2',
      title: 'মাসিক টিম মিটিং',
      content: 'আগামী শুক্রবার (৩১ জানুয়ারি) বিকাল ৩টায় কনফারেন্স রুমে মাসিক টিম মিটিং অনুষ্ঠিত হবে। সকল স্টাফের উপস্থিতি বাধ্যতামূলক।',
      publishedBy: '1',
      publishedDate: '2025-01-27',
      priority: 'Medium'
    },
    {
      id: '3',
      title: 'নতুন প্রজেক্ট শুরু',
      content: 'আমরা একটি নতুন ওয়েব ডেভেলপমেন্ট প্রজেক্ট শুরু করতে যাচ্ছি। আগ্রহী স্টাফরা আগামী সোমবারের মধ্যে আবেদন করতে পারেন।',
      publishedBy: '1',
      publishedDate: '2025-01-25',
      priority: 'Low'
    }
  ]);

  const [newNotice, setNewNotice] = useState({
    title: '',
    content: '',
    priority: 'Medium' as 'Low' | 'Medium' | 'High'
  });

  const handleAddNotice = (e: React.FormEvent) => {
    e.preventDefault();
    const notice: Notice = {
      id: Date.now().toString(),
      ...newNotice,
      publishedBy: user?.id || '1',
      publishedDate: new Date().toISOString().split('T')[0]
    };
    setNotices([notice, ...notices]);
    setNewNotice({ title: '', content: '', priority: 'Medium' });
    setShowAddForm(false);
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'High': return 'text-red-600 bg-red-100';
      case 'Medium': return 'text-yellow-600 bg-yellow-100';
      case 'Low': return 'text-green-600 bg-green-100';
      default: return 'text-gray-600 bg-gray-100';
    }
  };

  const getPriorityIcon = (priority: string) => {
    switch (priority) {
      case 'High': return <AlertCircle className="w-4 h-4" />;
      case 'Medium': return <Info className="w-4 h-4" />;
      case 'Low': return <CheckCircle className="w-4 h-4" />;
      default: return <Info className="w-4 h-4" />;
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-2xl font-bold text-gray-900 flex items-center">
            <MessageSquare className="w-6 h-6 mr-2" />
            {user?.role === 'manager' ? 'নোটিশ বোর্ড ব্যবস্থাপনা' : 'নোটিশ বোর্ড'}
          </h1>
          <p className="text-gray-600 mt-1">
            {user?.role === 'manager' 
              ? 'সকল স্টাফের জন্য নোটিশ প্রকাশ করুন'
              : 'গুরুত্বপূর্ণ নোটিশ ও ঘোষণা দেখুন'
            }
          </p>
        </div>
        {user?.role === 'manager' && (
          <button
            onClick={() => setShowAddForm(true)}
            className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg flex items-center transition-colors"
          >
            <Plus className="w-4 h-4 mr-2" />
            নতুন নোটিশ
          </button>
        )}
      </div>

      {/* Add Notice Form Modal */}
      {showAddForm && user?.role === 'manager' && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-lg p-6 w-full max-w-md max-h-[90vh] overflow-y-auto">
            <h2 className="text-xl font-bold mb-4">নতুন নোটিশ প্রকাশ</h2>
            <form onSubmit={handleAddNotice} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">শিরোনাম</label>
                <input
                  type="text"
                  required
                  value={newNotice.title}
                  onChange={(e) => setNewNotice({...newNotice, title: e.target.value})}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  placeholder="নোটিশের শিরোনাম"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">বিষয়বস্তু</label>
                <textarea
                  required
                  value={newNotice.content}
                  onChange={(e) => setNewNotice({...newNotice, content: e.target.value})}
                  rows={5}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  placeholder="নোটিশের বিস্তারিত বিষয়বস্তু লিখুন..."
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">অগ্রাধিকার</label>
                <select
                  value={newNotice.priority}
                  onChange={(e) => setNewNotice({...newNotice, priority: e.target.value as 'Low' | 'Medium' | 'High'})}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                >
                  <option value="Low">কম</option>
                  <option value="Medium">মাঝারি</option>
                  <option value="High">বেশি</option>
                </select>
              </div>
              <div className="flex gap-3 pt-4">
                <button
                  type="submit"
                  className="flex-1 bg-blue-600 hover:bg-blue-700 text-white py-2 px-4 rounded-lg transition-colors"
                >
                  প্রকাশ করুন
                </button>
                <button
                  type="button"
                  onClick={() => setShowAddForm(false)}
                  className="flex-1 bg-gray-300 hover:bg-gray-400 text-gray-700 py-2 px-4 rounded-lg transition-colors"
                >
                  বাতিল
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Notices List */}
      <div className="space-y-4">
        {notices.map((notice) => (
          <div key={notice.id} className="bg-white rounded-lg shadow-sm border border-gray-200 p-6 hover:shadow-md transition-shadow">
            <div className="flex items-start justify-between mb-4">
              <div className="flex-1">
                <div className="flex items-center gap-3 mb-2">
                  <h3 className="text-lg font-semibold text-gray-900">{notice.title}</h3>
                  <span className={`px-2 py-1 text-xs rounded-full flex items-center ${getPriorityColor(notice.priority)}`}>
                    {getPriorityIcon(notice.priority)}
                    <span className="ml-1">{notice.priority}</span>
                  </span>
                </div>
                <p className="text-gray-700 leading-relaxed">{notice.content}</p>
              </div>
            </div>

            <div className="flex items-center justify-between pt-4 border-t border-gray-200 text-sm text-gray-500">
              <div className="flex items-center">
                <User className="w-4 h-4 mr-2" />
                <span>প্রকাশক: {notice.publishedBy === '1' ? 'ম্যানেজার' : 'অ্যাডমিন'}</span>
              </div>
              <div className="flex items-center">
                <Calendar className="w-4 h-4 mr-2" />
                <span>{new Date(notice.publishedDate).toLocaleDateString('bn-BD')}</span>
              </div>
            </div>
          </div>
        ))}
      </div>

      {notices.length === 0 && (
        <div className="text-center py-12">
          <MessageSquare className="w-12 h-12 text-gray-400 mx-auto mb-4" />
          <p className="text-gray-600">কোন নোটিশ পাওয়া যায়নি</p>
        </div>
      )}
    </div>
  );
};
import React, { useState } from 'react';
import { 
  BarChart3, 
  Calendar, 
  DollarSign, 
  Users, 
  Clock,
  TrendingUp,
  TrendingDown,
  Activity,
  FileText,
  Palette
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { DesignSubmission } from '../../types';

export const ReportsSection: React.FC = () => {
  const { user } = useAuth();
  const [selectedReport, setSelectedReport] = useState('financial');
  const [dateRange, setDateRange] = useState({
    startDate: '2025-01-01',
    endDate: '2025-01-31'
  });

  // Sample design submission data
  const designSubmissions: DesignSubmission[] = [
    {
      id: '1',
      userId: '2',
      date: '2025-01-29',
      regularDesigns: 8,
      completedDesigns: 6,
      submittedBy: '2',
      submissionTime: '18:30:00'
    },
    {
      id: '2',
      userId: '2',
      date: '2025-01-28',
      regularDesigns: 10,
      completedDesigns: 8,
      submittedBy: '2',
      submissionTime: '17:45:00'
    },
    {
      id: '3',
      userId: '3',
      date: '2025-01-29',
      regularDesigns: 6,
      completedDesigns: 5,
      submittedBy: '3',
      submissionTime: '18:15:00'
    },
    {
      id: '4',
      userId: '3',
      date: '2025-01-28',
      regularDesigns: 7,
      completedDesigns: 6,
      submittedBy: '3',
      submissionTime: '18:00:00'
    },
    {
      id: '5',
      userId: '2',
      date: '2025-01-27',
      regularDesigns: 12,
      completedDesigns: 10,
      submittedBy: '2',
      submissionTime: '18:00:00'
    }
  ];

  const staffList = [
    { id: '2', name: 'ফাতিমা আহমেদ' },
    { id: '3', name: 'রহিম উদ্দিন' },
    { id: '4', name: 'সারা খাতুন' }
  ];

  // Sample data for reports
  const financialData = {
    totalIncome: 850000,
    totalExpense: 320000,
    netProfit: 530000,
    monthlyIncome: [120000, 150000, 180000, 200000],
    monthlyExpense: [80000, 75000, 85000, 80000],
    categories: {
      income: [
        { name: 'প্রজেক্ট আয়', amount: 500000 },
        { name: 'সার্ভিস আয়', amount: 250000 },
        { name: 'কনসালটেশন', amount: 100000 }
      ],
      expense: [
        { name: 'বেতন', amount: 200000 },
        { name: 'অফিস খরচ', amount: 50000 },
        { name: 'ইউটিলিটি', amount: 30000 },
        { name: 'অন্যান্য', amount: 40000 }
      ]
    }
  };

  const attendanceData = {
    totalStaff: 15,
    presentToday: 12,
    averageAttendance: 85,
    lateArrivals: 3,
    monthlyAttendance: [
      { date: '2025-01-01', present: 14, late: 1, absent: 0 },
      { date: '2025-01-02', present: 13, late: 2, absent: 0 },
      { date: '2025-01-03', present: 15, late: 0, absent: 0 },
      { date: '2025-01-04', present: 12, late: 2, absent: 1 }
    ]
  };

  const performanceData = {
    totalTasks: 73,
    completedTasks: 45,
    inProgressTasks: 28,
    completionRate: 62,
    averageTaskTime: 4.5,
    topPerformers: [
      { name: 'ফাতিমা আহমেদ', completedTasks: 15, totalHours: 120 },
      { name: 'রহিম উদ্দিন', completedTasks: 12, totalHours: 95 },
      { name: 'সারা খাতুন', completedTasks: 10, totalHours: 85 }
    ]
  };

  const renderFinancialReport = () => (
    <div className="space-y-6">
      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-gradient-to-r from-green-500 to-green-600 rounded-lg p-6 text-white">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-green-100 text-sm">মোট আয়</p>
              <p className="text-2xl font-bold">৳{financialData.totalIncome.toLocaleString()}</p>
            </div>
            <TrendingUp className="w-8 h-8 text-green-200" />
          </div>
        </div>

        <div className="bg-gradient-to-r from-red-500 to-red-600 rounded-lg p-6 text-white">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-red-100 text-sm">মোট ব্যয়</p>
              <p className="text-2xl font-bold">৳{financialData.totalExpense.toLocaleString()}</p>
            </div>
            <TrendingDown className="w-8 h-8 text-red-200" />
          </div>
        </div>

        <div className="bg-gradient-to-r from-blue-500 to-blue-600 rounded-lg p-6 text-white">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-blue-100 text-sm">নিট লাভ</p>
              <p className="text-2xl font-bold">৳{financialData.netProfit.toLocaleString()}</p>
            </div>
            <BarChart3 className="w-8 h-8 text-blue-200" />
          </div>
        </div>
      </div>

      {/* Category Breakdown */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">আয়ের বিভাগ</h3>
          <div className="space-y-3">
            {financialData.categories.income.map((category, index) => (
              <div key={index} className="flex items-center justify-between">
                <span className="text-gray-600">{category.name}</span>
                <span className="font-semibold text-green-600">৳{category.amount.toLocaleString()}</span>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">ব্যয়ের বিভাগ</h3>
          <div className="space-y-3">
            {financialData.categories.expense.map((category, index) => (
              <div key={index} className="flex items-center justify-between">
                <span className="text-gray-600">{category.name}</span>
                <span className="font-semibold text-red-600">৳{category.amount.toLocaleString()}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );

  const renderAttendanceReport = () => (
    <div className="space-y-6">
      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-gray-600 text-sm">মোট স্টাফ</p>
              <p className="text-2xl font-bold text-gray-900">{attendanceData.totalStaff}</p>
            </div>
            <Users className="w-8 h-8 text-blue-600" />
          </div>
        </div>

        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-gray-600 text-sm">আজ উপস্থিত</p>
              <p className="text-2xl font-bold text-green-600">{attendanceData.presentToday}</p>
            </div>
            <Clock className="w-8 h-8 text-green-600" />
          </div>
        </div>

        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-gray-600 text-sm">গড় উপস্থিতি</p>
              <p className="text-2xl font-bold text-blue-600">{attendanceData.averageAttendance}%</p>
            </div>
            <TrendingUp className="w-8 h-8 text-blue-600" />
          </div>
        </div>

        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-gray-600 text-sm">দেরি করে আসা</p>
              <p className="text-2xl font-bold text-orange-600">{attendanceData.lateArrivals}</p>
            </div>
            <Clock className="w-8 h-8 text-orange-600" />
          </div>
        </div>
      </div>

      {/* Daily Attendance Table */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-200">
        <div className="p-6 border-b border-gray-200">
          <h3 className="text-lg font-semibold text-gray-900">দৈনিক উপস্থিতি</h3>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">তারিখ</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">উপস্থিত</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">দেরি</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">অনুপস্থিত</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">উপস্থিতির হার</th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {attendanceData.monthlyAttendance.map((day, index) => {
                const total = day.present + day.late + day.absent;
                const rate = Math.round(((day.present + day.late) / total) * 100);
                return (
                  <tr key={index} className="hover:bg-gray-50">
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                      {new Date(day.date).toLocaleDateString('bn-BD')}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-green-600 font-semibold">
                      {day.present}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-orange-600 font-semibold">
                      {day.late}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-red-600 font-semibold">
                      {day.absent}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                      {rate}%
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );

  const renderPerformanceReport = () => (
    <div className="space-y-6">
      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-gray-600 text-sm">মোট টাস্ক</p>
              <p className="text-2xl font-bold text-gray-900">{performanceData.totalTasks}</p>
            </div>
            <FileText className="w-8 h-8 text-blue-600" />
          </div>
        </div>

        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-gray-600 text-sm">সম্পন্ন টাস্ক</p>
              <p className="text-2xl font-bold text-green-600">{performanceData.completedTasks}</p>
            </div>
            <Activity className="w-8 h-8 text-green-600" />
          </div>
        </div>

        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-gray-600 text-sm">সম্পন্নের হার</p>
              <p className="text-2xl font-bold text-blue-600">{performanceData.completionRate}%</p>
            </div>
            <TrendingUp className="w-8 h-8 text-blue-600" />
          </div>
        </div>

        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-gray-600 text-sm">গড় সময় (ঘন্টা)</p>
              <p className="text-2xl font-bold text-purple-600">{performanceData.averageTaskTime}</p>
            </div>
            <Clock className="w-8 h-8 text-purple-600" />
          </div>
        </div>
      </div>

      {/* Top Performers */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-200">
        <div className="p-6 border-b border-gray-200">
          <h3 className="text-lg font-semibold text-gray-900">সেরা পারফরমার</h3>
        </div>
        <div className="p-6">
          <div className="space-y-4">
            {performanceData.topPerformers.map((performer, index) => (
              <div key={index} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                <div className="flex items-center">
                  <div className={`w-8 h-8 rounded-full flex items-center justify-center text-white font-bold mr-4 ${
                    index === 0 ? 'bg-yellow-500' : index === 1 ? 'bg-gray-400' : 'bg-orange-500'
                  }`}>
                    {index + 1}
                  </div>
                  <div>
                    <p className="font-semibold text-gray-900">{performer.name}</p>
                    <p className="text-sm text-gray-600">{performer.completedTasks} টাস্ক সম্পন্ন</p>
                  </div>
                </div>
                <div className="text-right">
                  <p className="font-semibold text-blue-600">{performer.totalHours}h</p>
                  <p className="text-sm text-gray-600">মোট সময়</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );

  const renderDesignReport = () => {
    // Calculate design statistics
    const totalRegularDesigns = designSubmissions.reduce((sum, sub) => sum + sub.regularDesigns, 0);
    const totalCompletedDesigns = designSubmissions.reduce((sum, sub) => sum + sub.completedDesigns, 0);
    const averageRegular = Math.round(totalRegularDesigns / designSubmissions.length);
    const averageCompleted = Math.round(totalCompletedDesigns / designSubmissions.length);
    const completionRate = Math.round((totalCompletedDesigns / totalRegularDesigns) * 100);
    
    const regularDesigns = designSubmissions.map(sub => sub.regularDesigns);
    const completedDesigns = designSubmissions.map(sub => sub.completedDesigns);
    
    const minRegular = Math.min(...regularDesigns);
    const maxRegular = Math.max(...regularDesigns);
    const minCompleted = Math.min(...completedDesigns);
    const maxCompleted = Math.max(...completedDesigns);

    // Group by staff
    const staffStats = staffList.map(staff => {
      const staffSubmissions = designSubmissions.filter(sub => sub.userId === staff.id);
      const staffTotal = staffSubmissions.reduce((sum, sub) => sum + sub.completedDesigns, 0);
      const staffRegular = staffSubmissions.reduce((sum, sub) => sum + sub.regularDesigns, 0);
      return {
        ...staff,
        totalCompleted: staffTotal,
        totalRegular: staffRegular,
        completionRate: staffRegular > 0 ? Math.round((staffTotal / staffRegular) * 100) : 0,
        submissions: staffSubmissions.length
      };
    });

    return (
      <div className="space-y-6">
        {/* Summary Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
          <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-600 text-sm">মোট রেগুলার ডিজাইন</p>
                <p className="text-2xl font-bold text-blue-600">{totalRegularDesigns}</p>
              </div>
              <Palette className="w-8 h-8 text-blue-600" />
            </div>
          </div>

          <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-600 text-sm">মোট সম্পন্ন ডিজাইন</p>
                <p className="text-2xl font-bold text-green-600">{totalCompletedDesigns}</p>
              </div>
              <Activity className="w-8 h-8 text-green-600" />
            </div>
          </div>

          <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-600 text-sm">সম্পন্নের হার</p>
                <p className="text-2xl font-bold text-purple-600">{completionRate}%</p>
              </div>
              <TrendingUp className="w-8 h-8 text-purple-600" />
            </div>
          </div>

          <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-600 text-sm">গড় দৈনিক</p>
                <p className="text-2xl font-bold text-orange-600">{averageCompleted}</p>
              </div>
              <BarChart3 className="w-8 h-8 text-orange-600" />
            </div>
          </div>
        </div>

        {/* Statistics Overview */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">পরিসংখ্যান সারাংশ</h3>
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <span className="text-gray-600">গড় রেগুলার ডিজাইন</span>
                <span className="font-semibold text-blue-600">{averageRegular}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-gray-600">গড় সম্পন্ন ডিজাইন</span>
                <span className="font-semibold text-green-600">{averageCompleted}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-gray-600">সর্বনিম্ন রেগুলার</span>
                <span className="font-semibold text-red-600">{minRegular}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-gray-600">সর্বোচ্চ রেগুলার</span>
                <span className="font-semibold text-green-600">{maxRegular}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-gray-600">সর্বনিম্ন সম্পন্ন</span>
                <span className="font-semibold text-red-600">{minCompleted}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-gray-600">সর্বোচ্চ সম্পন্ন</span>
                <span className="font-semibold text-green-600">{maxCompleted}</span>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">স্টাফ অনুযায়ী পারফরম্যান্স</h3>
            <div className="space-y-4">
              {staffStats.map((staff, index) => (
                <div key={staff.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                  <div>
                    <p className="font-semibold text-gray-900">{staff.name}</p>
                    <p className="text-sm text-gray-600">{staff.submissions} দিনের ডেটা</p>
                  </div>
                  <div className="text-right">
                    <p className="font-semibold text-blue-600">{staff.totalCompleted}/{staff.totalRegular}</p>
                    <p className="text-sm text-gray-600">{staff.completionRate}% সম্পন্ন</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Daily Design Submissions Table */}
        <div className="bg-white rounded-lg shadow-sm border border-gray-200">
          <div className="p-6 border-b border-gray-200">
            <h3 className="text-lg font-semibold text-gray-900">দৈনিক ডিজাইন সাবমিশন</h3>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">তারিখ</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">স্টাফ</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">রেগুলার</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">সম্পন্ন</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">হার</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">সময়</th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {designSubmissions.map((submission) => {
                  const staff = staffList.find(s => s.id === submission.userId);
                  const rate = Math.round((submission.completedDesigns / submission.regularDesigns) * 100);
                  return (
                    <tr key={submission.id} className="hover:bg-gray-50">
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                        {new Date(submission.date).toLocaleDateString('bn-BD')}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                        {staff?.name}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm font-semibold text-blue-600">
                        {submission.regularDesigns}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm font-semibold text-green-600">
                        {submission.completedDesigns}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <span className={`px-2 py-1 text-xs rounded-full ${
                          rate >= 80 ? 'bg-green-100 text-green-800' :
                          rate >= 60 ? 'bg-yellow-100 text-yellow-800' :
                          'bg-red-100 text-red-800'
                        }`}>
                          {rate}%
                        </span>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-600">
                        {submission.submissionTime}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    );
  };

  if (user?.role !== 'manager') {
    return (
      <div className="text-center py-12">
        <BarChart3 className="w-12 h-12 text-gray-400 mx-auto mb-4" />
        <p className="text-gray-600">এই বিভাগটি শুধুমাত্র ম্যানেজারদের জন্য</p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-bold text-gray-900 flex items-center">
          <BarChart3 className="w-6 h-6 mr-2" />
          রিপোর্টস ও বিশ্লেষণ
        </h1>
        <p className="text-gray-600 mt-1">বিস্তারিত ডেটা বিশ্লেষণ এবং পারফরম্যান্স রিপোর্ট</p>
      </div>

      {/* Date Range Selector */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
        <div className="flex flex-col sm:flex-row gap-4 items-start sm:items-center">
          <div className="flex items-center gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">শুরুর তারিখ</label>
              <input
                type="date"
                value={dateRange.startDate}
                onChange={(e) => setDateRange({...dateRange, startDate: e.target.value})}
                className="px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">শেষ তারিখ</label>
              <input
                type="date"
                value={dateRange.endDate}
                onChange={(e) => setDateRange({...dateRange, endDate: e.target.value})}
                className="px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
            </div>
          </div>
        </div>
      </div>

      {/* Report Type Selector */}
      <div className="flex flex-wrap gap-2">
        <button
          onClick={() => setSelectedReport('financial')}
          className={`px-4 py-2 rounded-lg font-medium transition-colors ${
            selectedReport === 'financial'
              ? 'bg-blue-600 text-white'
              : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
          }`}
        >
          <DollarSign className="w-4 h-4 inline mr-2" />
          আর্থিক রিপোর্ট
        </button>
        <button
          onClick={() => setSelectedReport('attendance')}
          className={`px-4 py-2 rounded-lg font-medium transition-colors ${
            selectedReport === 'attendance'
              ? 'bg-blue-600 text-white'
              : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
          }`}
        >
          <Clock className="w-4 h-4 inline mr-2" />
          উপস্থিতি রিপোর্ট
        </button>
        <button
          onClick={() => setSelectedReport('performance')}
          className={`px-4 py-2 rounded-lg font-medium transition-colors ${
            selectedReport === 'performance'
              ? 'bg-blue-600 text-white'
              : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
          }`}
        >
          <Activity className="w-4 h-4 inline mr-2" />
          পারফরম্যান্স রিপোর্ট
        </button>
        <button
          onClick={() => setSelectedReport('design')}
          className={`px-4 py-2 rounded-lg font-medium transition-colors ${
            selectedReport === 'design'
              ? 'bg-blue-600 text-white'
              : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
          }`}
        >
          <Palette className="w-4 h-4 inline mr-2" />
          ডিজাইন রিপোর্ট
        </button>
      </div>

      {/* Report Content */}
      {selectedReport === 'financial' && renderFinancialReport()}
      {selectedReport === 'attendance' && renderAttendanceReport()}
      {selectedReport === 'performance' && renderPerformanceReport()}
      {selectedReport === 'design' && renderDesignReport()}
    </div>
  );
};
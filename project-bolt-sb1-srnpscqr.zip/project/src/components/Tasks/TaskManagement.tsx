import React, { useState } from 'react';
import { 
  CheckSquare, 
  Plus, 
  Clock, 
  User, 
  Calendar,
  PlayCircle,
  PauseCircle,
  CheckCircle,
  AlertCircle
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { Task, TaskActivity } from '../../types';

export const TaskManagement: React.FC = () => {
  const { user } = useAuth();
  const [showAddForm, setShowAddForm] = useState(false);
  const [activeTaskId, setActiveTaskId] = useState<string | null>(null);

  const [tasks, setTasks] = useState<Task[]>([
    {
      id: '1',
      title: 'ওয়েবসাইট ডিজাইন আপডেট',
      description: 'কোম্পানির ওয়েবসাইটের হোম পেজ ডিজাইন আপডেট করুন',
      assignedTo: '2',
      assignedBy: '1',
      deadline: '2025-02-05',
      status: 'In Progress',
      priority: 'High',
      createdDate: '2025-01-25'
    },
    {
      id: '2',
      title: 'ডেটাবেস অপ্টিমাইজেশন',
      description: 'ডেটাবেস কোয়েরি অপ্টিমাইজ করে পারফরম্যান্স উন্নত করুন',
      assignedTo: '2',
      assignedBy: '1',
      deadline: '2025-02-10',
      status: 'To Do',
      priority: 'Medium',
      createdDate: '2025-01-28'
    },
    {
      id: '3',
      title: 'ক্লায়েন্ট প্রেজেন্টেশন প্রস্তুতি',
      description: 'আগামী সপ্তাহের ক্লায়েন্ট মিটিংয়ের জন্য প্রেজেন্টেশন তৈরি করুন',
      assignedTo: '3',
      assignedBy: '1',
      deadline: '2025-02-03',
      status: 'Completed',
      priority: 'High',
      createdDate: '2025-01-20'
    }
  ]);

  const [taskActivities, setTaskActivities] = useState<TaskActivity[]>([
    {
      id: '1',
      taskId: '1',
      userId: '2',
      startTime: '2025-01-29T09:30:00',
      endTime: '2025-01-29T12:30:00',
      duration: 180,
      isActive: false
    }
  ]);

  const [newTask, setNewTask] = useState({
    title: '',
    description: '',
    assignedTo: '',
    deadline: '',
    priority: 'Medium' as 'Low' | 'Medium' | 'High'
  });

  const staffList = [
    { id: '2', name: 'ফাতিমা আহমেদ' },
    { id: '3', name: 'রহিম উদ্দিন' },
    { id: '4', name: 'সারা খাতুন' }
  ];

  const userTasks = user?.role === 'staff' 
    ? tasks.filter(task => task.assignedTo === user.id)
    : tasks;

  const handleAddTask = (e: React.FormEvent) => {
    e.preventDefault();
    const task: Task = {
      id: Date.now().toString(),
      ...newTask,
      assignedBy: user?.id || '1',
      status: 'To Do',
      createdDate: new Date().toISOString().split('T')[0]
    };
    setTasks([...tasks, task]);
    setNewTask({ title: '', description: '', assignedTo: '', deadline: '', priority: 'Medium' });
    setShowAddForm(false);
  };

  const handleStartTask = (taskId: string) => {
    const activity: TaskActivity = {
      id: Date.now().toString(),
      taskId,
      userId: user?.id || '',
      startTime: new Date().toISOString(),
      isActive: true,
      duration: 0
    };
    setTaskActivities([...taskActivities, activity]);
    setActiveTaskId(taskId);
    
    // Update task status to In Progress
    setTasks(tasks.map(task => 
      task.id === taskId ? { ...task, status: 'In Progress' } : task
    ));
  };

  const handleStopTask = (taskId: string) => {
    const activeActivity = taskActivities.find(
      activity => activity.taskId === taskId && activity.isActive
    );
    
    if (activeActivity) {
      const endTime = new Date();
      const startTime = new Date(activeActivity.startTime);
      const duration = Math.round((endTime.getTime() - startTime.getTime()) / (1000 * 60));
      
      setTaskActivities(taskActivities.map(activity =>
        activity.id === activeActivity.id
          ? { ...activity, endTime: endTime.toISOString(), duration, isActive: false }
          : activity
      ));
      setActiveTaskId(null);
    }
  };

  const handleCompleteTask = (taskId: string) => {
    setTasks(tasks.map(task =>
      task.id === taskId ? { ...task, status: 'Completed' } : task
    ));
    
    // Stop any active tracking for this task
    if (activeTaskId === taskId) {
      handleStopTask(taskId);
    }
  };

  const getTaskTotalTime = (taskId: string) => {
    const activities = taskActivities.filter(activity => activity.taskId === taskId);
    const totalMinutes = activities.reduce((sum, activity) => sum + (activity.duration || 0), 0);
    const hours = Math.floor(totalMinutes / 60);
    const minutes = totalMinutes % 60;
    return `${hours}h ${minutes}m`;
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'High': return 'text-red-600 bg-red-100';
      case 'Medium': return 'text-yellow-600 bg-yellow-100';
      case 'Low': return 'text-green-600 bg-green-100';
      default: return 'text-gray-600 bg-gray-100';
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'Completed': return 'text-green-600 bg-green-100';
      case 'In Progress': return 'text-blue-600 bg-blue-100';
      case 'To Do': return 'text-gray-600 bg-gray-100';
      default: return 'text-gray-600 bg-gray-100';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'Completed': return <CheckCircle className="w-4 h-4" />;
      case 'In Progress': return <Clock className="w-4 h-4" />;
      case 'To Do': return <AlertCircle className="w-4 h-4" />;
      default: return <CheckSquare className="w-4 h-4" />;
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-2xl font-bold text-gray-900 flex items-center">
            <CheckSquare className="w-6 h-6 mr-2" />
            {user?.role === 'manager' ? 'টাস্ক ম্যানেজমেন্ট' : 'আমার টাস্ক'}
          </h1>
          <p className="text-gray-600 mt-1">
            {user?.role === 'manager' 
              ? 'স্টাফদের কাজ বরাদ্দ করুন এবং অগ্রগতি ট্র্যাক করুন'
              : 'আপনার কাজের তালিকা এবং অগ্রগতি দেখুন'
            }
          </p>
        </div>
        {user?.role === 'manager' && (
          <button
            onClick={() => setShowAddForm(true)}
            className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg flex items-center transition-colors"
          >
            <Plus className="w-4 h-4 mr-2" />
            নতুন টাস্ক যুক্ত করুন
          </button>
        )}
      </div>

      {/* Add Task Form Modal */}
      {showAddForm && user?.role === 'manager' && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-lg p-6 w-full max-w-md max-h-[90vh] overflow-y-auto">
            <h2 className="text-xl font-bold mb-4">নতুন টাস্ক যুক্ত করুন</h2>
            <form onSubmit={handleAddTask} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">টাস্কের নাম</label>
                <input
                  type="text"
                  required
                  value={newTask.title}
                  onChange={(e) => setNewTask({...newTask, title: e.target.value})}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">বিবরণ</label>
                <textarea
                  required
                  value={newTask.description}
                  onChange={(e) => setNewTask({...newTask, description: e.target.value})}
                  rows={3}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">বরাদ্দ করুন</label>
                <select
                  required
                  value={newTask.assignedTo}
                  onChange={(e) => setNewTask({...newTask, assignedTo: e.target.value})}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                >
                  <option value="">স্টাফ নির্বাচন করুন</option>
                  {staffList.map(staff => (
                    <option key={staff.id} value={staff.id}>{staff.name}</option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">শেষ তারিখ</label>
                <input
                  type="date"
                  required
                  value={newTask.deadline}
                  onChange={(e) => setNewTask({...newTask, deadline: e.target.value})}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">অগ্রাধিকার</label>
                <select
                  value={newTask.priority}
                  onChange={(e) => setNewTask({...newTask, priority: e.target.value as 'Low' | 'Medium' | 'High'})}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                >
                  <option value="Low">কম</option>
                  <option value="Medium">মাঝারি</option>
                  <option value="High">বেশি</option>
                </select>
              </div>
              <div className="flex gap-3 pt-4">
                <button
                  type="submit"
                  className="flex-1 bg-blue-600 hover:bg-blue-700 text-white py-2 px-4 rounded-lg transition-colors"
                >
                  যুক্ত করুন
                </button>
                <button
                  type="button"
                  onClick={() => setShowAddForm(false)}
                  className="flex-1 bg-gray-300 hover:bg-gray-400 text-gray-700 py-2 px-4 rounded-lg transition-colors"
                >
                  বাতিল
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Tasks Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-6">
        {userTasks.map((task) => {
          const assignedStaff = staffList.find(staff => staff.id === task.assignedTo);
          const isActive = activeTaskId === task.id;
          const totalTime = getTaskTotalTime(task.id);
          
          return (
            <div key={task.id} className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
              <div className="flex items-start justify-between mb-4">
                <div className="flex-1">
                  <h3 className="font-semibold text-gray-900 mb-2">{task.title}</h3>
                  <p className="text-sm text-gray-600 mb-3">{task.description}</p>
                </div>
                <span className={`px-2 py-1 text-xs rounded-full flex items-center ${getPriorityColor(task.priority)}`}>
                  {task.priority}
                </span>
              </div>

              <div className="space-y-3 mb-4">
                <div className="flex items-center text-sm text-gray-600">
                  <User className="w-4 h-4 mr-2" />
                  {user?.role === 'manager' ? assignedStaff?.name : 'আপনার কাজ'}
                </div>
                <div className="flex items-center text-sm text-gray-600">
                  <Calendar className="w-4 h-4 mr-2" />
                  শেষ তারিখ: {new Date(task.deadline).toLocaleDateString('bn-BD')}
                </div>
                <div className="flex items-center text-sm text-gray-600">
                  <Clock className="w-4 h-4 mr-2" />
                  মোট সময়: {totalTime}
                </div>
              </div>

              <div className="flex items-center justify-between mb-4">
                <span className={`px-2 py-1 text-xs rounded-full flex items-center ${getStatusColor(task.status)}`}>
                  {getStatusIcon(task.status)}
                  <span className="ml-1">{task.status}</span>
                </span>
              </div>

              {/* Task Actions for Staff */}
              {user?.role === 'staff' && task.assignedTo === user.id && task.status !== 'Completed' && (
                <div className="flex gap-2">
                  {!isActive ? (
                    <button
                      onClick={() => handleStartTask(task.id)}
                      className="flex-1 bg-green-600 hover:bg-green-700 text-white py-2 px-3 rounded-lg flex items-center justify-center text-sm transition-colors"
                    >
                      <PlayCircle className="w-4 h-4 mr-1" />
                      শুরু করুন
                    </button>
                  ) : (
                    <button
                      onClick={() => handleStopTask(task.id)}
                      className="flex-1 bg-red-600 hover:bg-red-700 text-white py-2 px-3 rounded-lg flex items-center justify-center text-sm transition-colors"
                    >
                      <PauseCircle className="w-4 h-4 mr-1" />
                      বন্ধ করুন
                    </button>
                  )}
                  
                  {task.status === 'In Progress' && (
                    <button
                      onClick={() => handleCompleteTask(task.id)}
                      className="flex-1 bg-blue-600 hover:bg-blue-700 text-white py-2 px-3 rounded-lg flex items-center justify-center text-sm transition-colors"
                    >
                      <CheckCircle className="w-4 h-4 mr-1" />
                      সম্পন্ন
                    </button>
                  )}
                </div>
              )}
            </div>
          );
        })}
      </div>

      {userTasks.length === 0 && (
        <div className="text-center py-12">
          <CheckSquare className="w-12 h-12 text-gray-400 mx-auto mb-4" />
          <p className="text-gray-600">কোন টাস্ক পাওয়া যায়নি</p>
        </div>
      )}
    </div>
  );
};
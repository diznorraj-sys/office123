import React, { useState } from 'react';
import { 
  Palette, 
  Plus, 
  Calendar, 
  User,
  TrendingUp,
  BarChart3,
  CheckCircle
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { DesignSubmission } from '../../types';

export const DesignSubmitManager: React.FC = () => {
  const { user } = useAuth();
  const [showSubmitForm, setShowSubmitForm] = useState(false);

  const [designSubmissions, setDesignSubmissions] = useState<DesignSubmission[]>([
    {
      id: '1',
      userId: '2',
      date: '2025-01-29',
      regularDesigns: 8,
      completedDesigns: 6,
      submittedBy: '2',
      submissionTime: '18:30:00'
    },
    {
      id: '2',
      userId: '2',
      date: '2025-01-28',
      regularDesigns: 10,
      completedDesigns: 8,
      submittedBy: '2',
      submissionTime: '17:45:00'
    },
    {
      id: '3',
      userId: '3',
      date: '2025-01-29',
      regularDesigns: 6,
      completedDesigns: 5,
      submittedBy: '3',
      submissionTime: '18:15:00'
    },
    {
      id: '4',
      userId: '3',
      date: '2025-01-28',
      regularDesigns: 7,
      completedDesigns: 6,
      submittedBy: '3',
      submissionTime: '18:00:00'
    }
  ]);

  const [newSubmission, setNewSubmission] = useState({
    regularDesigns: '',
    completedDesigns: ''
  });

  const staffList = [
    { id: '2', name: 'ফাতিমা আহমেদ' },
    { id: '3', name: 'রহিম উদ্দিন' },
    { id: '4', name: 'সারা খাতুন' }
  ];

  const userSubmissions = user?.role === 'staff' 
    ? designSubmissions.filter(submission => submission.userId === user.id)
    : designSubmissions;

  const handleSubmitDesign = (e: React.FormEvent) => {
    e.preventDefault();
    const submission: DesignSubmission = {
      id: Date.now().toString(),
      userId: user?.id || '',
      date: new Date().toISOString().split('T')[0],
      regularDesigns: parseInt(newSubmission.regularDesigns),
      completedDesigns: parseInt(newSubmission.completedDesigns),
      submittedBy: user?.id || '',
      submissionTime: new Date().toTimeString().split(' ')[0]
    };
    setDesignSubmissions([submission, ...designSubmissions]);
    setNewSubmission({ regularDesigns: '', completedDesigns: '' });
    setShowSubmitForm(false);
  };

  // Calculate today's progress for staff
  const todaySubmission = userSubmissions.find(
    sub => sub.date === new Date().toISOString().split('T')[0] && sub.userId === user?.id
  );

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-2xl font-bold text-gray-900 flex items-center">
            <Palette className="w-6 h-6 mr-2" />
            {user?.role === 'manager' ? 'ডিজাইন সাবমিট ব্যবস্থাপনা' : 'আমার ডিজাইন সাবমিট'}
          </h1>
          <p className="text-gray-600 mt-1">
            {user?.role === 'manager' 
              ? 'সকল স্টাফের ডিজাইন কাজের অগ্রগতি দেখুন'
              : 'আপনার দৈনিক ডিজাইন কাজের রিপোর্ট জমা দিন'
            }
          </p>
        </div>
        {user?.role === 'staff' && (
          <button
            onClick={() => setShowSubmitForm(true)}
            className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg flex items-center transition-colors"
          >
            <Plus className="w-4 h-4 mr-2" />
            আজকের কাজ জমা দিন
          </button>
        )}
      </div>

      {/* Today's Progress for Staff */}
      {user?.role === 'staff' && (
        <div className="bg-gradient-to-r from-purple-600 to-purple-800 rounded-lg p-6 text-white">
          <h2 className="text-xl font-semibold mb-4">আজকের অগ্রগতি</h2>
          {todaySubmission ? (
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <div className="text-center">
                <p className="text-purple-100 text-sm">রেগুলার ডিজাইন</p>
                <p className="text-2xl font-bold">{todaySubmission.regularDesigns}</p>
              </div>
              <div className="text-center">
                <p className="text-purple-100 text-sm">সম্পন্ন ডিজাইন</p>
                <p className="text-2xl font-bold">{todaySubmission.completedDesigns}</p>
              </div>
              <div className="text-center">
                <p className="text-purple-100 text-sm">সম্পন্নের হার</p>
                <p className="text-2xl font-bold">
                  {Math.round((todaySubmission.completedDesigns / todaySubmission.regularDesigns) * 100)}%
                </p>
              </div>
              <div className="text-center">
                <p className="text-purple-100 text-sm">জমা দেওয়ার সময়</p>
                <p className="text-lg font-semibold">{todaySubmission.submissionTime}</p>
              </div>
            </div>
          ) : (
            <div className="text-center py-4">
              <p className="text-purple-100">আজকের কাজ এখনো জমা দেওয়া হয়নি</p>
            </div>
          )}
        </div>
      )}

      {/* Submit Form Modal */}
      {showSubmitForm && user?.role === 'staff' && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-lg p-6 w-full max-w-md">
            <h2 className="text-xl font-bold mb-4">আজকের ডিজাইন কাজ জমা দিন</h2>
            <form onSubmit={handleSubmitDesign} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  রেগুলার ডিজাইনের সংখ্যা
                </label>
                <input
                  type="number"
                  required
                  min="0"
                  value={newSubmission.regularDesigns}
                  onChange={(e) => setNewSubmission({...newSubmission, regularDesigns: e.target.value})}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  placeholder="আজ কতটি ডিজাইন পেয়েছেন?"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  সম্পন্ন ডিজাইনের সংখ্যা
                </label>
                <input
                  type="number"
                  required
                  min="0"
                  value={newSubmission.completedDesigns}
                  onChange={(e) => setNewSubmission({...newSubmission, completedDesigns: e.target.value})}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  placeholder="কতটি ডিজাইন সম্পন্ন করেছেন?"
                />
              </div>
              <div className="flex gap-3 pt-4">
                <button
                  type="submit"
                  className="flex-1 bg-blue-600 hover:bg-blue-700 text-white py-2 px-4 rounded-lg transition-colors"
                >
                  জমা দিন
                </button>
                <button
                  type="button"
                  onClick={() => setShowSubmitForm(false)}
                  className="flex-1 bg-gray-300 hover:bg-gray-400 text-gray-700 py-2 px-4 rounded-lg transition-colors"
                >
                  বাতিল
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Design Submissions List */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-200">
        <div className="p-6 border-b border-gray-200">
          <h2 className="text-lg font-semibold text-gray-900 flex items-center">
            <BarChart3 className="w-5 h-5 mr-2" />
            ডিজাইন সাবমিশন রেকর্ড
          </h2>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  তারিখ
                </th>
                {user?.role === 'manager' && (
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    স্টাফ
                  </th>
                )}
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  রেগুলার ডিজাইন
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  সম্পন্ন ডিজাইন
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  সম্পন্নের হার
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  জমা দেওয়ার সময়
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {userSubmissions.map((submission) => {
                const staffMember = staffList.find(staff => staff.id === submission.userId);
                const completionRate = Math.round((submission.completedDesigns / submission.regularDesigns) * 100);
                
                return (
                  <tr key={submission.id} className="hover:bg-gray-50">
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                      <div className="flex items-center">
                        <Calendar className="w-4 h-4 mr-2 text-gray-400" />
                        {new Date(submission.date).toLocaleDateString('bn-BD')}
                      </div>
                    </td>
                    {user?.role === 'manager' && (
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                        <div className="flex items-center">
                          <User className="w-4 h-4 mr-2 text-gray-400" />
                          {staffMember?.name}
                        </div>
                      </td>
                    )}
                    <td className="px-6 py-4 whitespace-nowrap text-sm font-semibold text-blue-600">
                      {submission.regularDesigns}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm font-semibold text-green-600">
                      {submission.completedDesigns}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="flex items-center">
                        <div className={`px-2 py-1 text-xs rounded-full ${
                          completionRate >= 80 ? 'bg-green-100 text-green-800' :
                          completionRate >= 60 ? 'bg-yellow-100 text-yellow-800' :
                          'bg-red-100 text-red-800'
                        }`}>
                          {completionRate}%
                        </div>
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-600">
                      {submission.submissionTime}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {userSubmissions.length === 0 && (
        <div className="text-center py-12">
          <Palette className="w-12 h-12 text-gray-400 mx-auto mb-4" />
          <p className="text-gray-600">কোন ডিজাইন সাবমিশন পাওয়া যায়নি</p>
        </div>
      )}
    </div>
  );
};
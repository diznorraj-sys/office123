import React, { useState } from 'react';
import { AuthProvider, useAuth } from './context/AuthContext';
import { NotificationProvider } from './context/NotificationContext';
import { LandingPage } from './components/LandingPage';
import { Header } from './components/Layout/Header';
import { Sidebar } from './components/Layout/Sidebar';
import { ManagerDashboard } from './components/Dashboard/ManagerDashboard';
import { StaffDashboard } from './components/Dashboard/StaffDashboard';
import { StaffList } from './components/StaffManagement/StaffList';
import { AttendanceTracker } from './components/Attendance/AttendanceTracker';
import { TaskManagement } from './components/Tasks/TaskManagement';
import { FinanceManagement } from './components/Finance/FinanceManagement';
import { LeaveManagement } from './components/Leaves/LeaveManagement';
import { NoticeBoard } from './components/Notices/NoticeBoard';
import { ReportsSection } from './components/Reports/ReportsSection';
import { WorkSubmissionManager } from './components/WorkSubmissions/WorkSubmissionManager';
import { DesignSubmitManager } from './components/DesignSubmit/DesignSubmitManager';
import { SettingsPage } from './components/Settings/SettingsPage';

const AppContent: React.FC = () => {
  const { user, isLoading } = useAuth();
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [currentPage, setCurrentPage] = useState('dashboard');

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  if (!user) {
    return <LandingPage />;
  }

  const renderContent = () => {
    switch (currentPage) {
      case 'dashboard':
        return user.role === 'manager' ? <ManagerDashboard /> : <StaffDashboard />;
      case 'staff':
        return (
          <StaffList />
        );
      case 'attendance':
        return <AttendanceTracker />;
      case 'leaves':
        return <LeaveManagement />;
      case 'tasks':
        return <TaskManagement />;
      case 'finance':
        return <FinanceManagement />;
      case 'reports':
        return <ReportsSection />;
      case 'notices':
        return <NoticeBoard />;
      case 'work-submissions':
        return <WorkSubmissionManager />;
      case 'design-submit':
        return <DesignSubmitManager />;
      case 'profile':
        return (
          <div className="p-6">
            <h2 className="text-2xl font-bold mb-4">প্রোফাইল</h2>
            <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
              <div className="space-y-4">
                <div>
                  <label className="text-sm font-medium text-gray-600">নাম</label>
                  <p className="text-gray-900">{user.name}</p>
                </div>
                <div>
                  <label className="text-sm font-medium text-gray-600">ইমেল</label>
                  <p className="text-gray-900">{user.email}</p>
                </div>
                <div>
                  <label className="text-sm font-medium text-gray-600">ভূমিকা</label>
                  <p className="text-gray-900 capitalize">{user.role}</p>
                </div>
                {user.phone && (
                  <div>
                    <label className="text-sm font-medium text-gray-600">ফোন</label>
                    <p className="text-gray-900">{user.phone}</p>
                  </div>
                )}
                {user.address && (
                  <div>
                    <label className="text-sm font-medium text-gray-600">ঠিকানা</label>
                    <p className="text-gray-900">{user.address}</p>
                  </div>
                )}
                {user.designation && (
                  <div>
                    <label className="text-sm font-medium text-gray-600">পদবী</label>
                    <p className="text-gray-900">{user.designation}</p>
                  </div>
                )}
              </div>
            </div>
          </div>
        );
      case 'settings':
        return (
          <SettingsPage />
        );
      default:
        return user.role === 'manager' ? <ManagerDashboard /> : <StaffDashboard />;
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Header sidebarOpen={sidebarOpen} setSidebarOpen={setSidebarOpen} />
      
      <div className="flex">
        <Sidebar 
          isOpen={sidebarOpen} 
          currentPage={currentPage} 
          setCurrentPage={setCurrentPage} 
        />
        
        <main className="flex-1 lg:ml-64">
          <div className="p-6">{renderContent()}</div>
        </main>
      </div>
    </div>
  );
};

function App() {
  return (
    <AuthProvider>
      <NotificationProvider>
        <AppContent />
      </NotificationProvider>
    </AuthProvider>
  );
}

export default App;